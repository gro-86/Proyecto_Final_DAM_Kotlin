package com.example.myapplication.interfaces

interface Refrescar {
    fun refrescar()
}