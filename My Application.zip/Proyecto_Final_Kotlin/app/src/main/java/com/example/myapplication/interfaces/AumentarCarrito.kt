package com.example.myapplication.interfaces

interface AumentarCarrito {
    fun aumentarCarrito()
}