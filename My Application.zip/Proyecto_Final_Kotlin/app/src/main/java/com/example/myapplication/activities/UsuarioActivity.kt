package com.example.myapplication.activities

import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.preference.PreferenceManager
import com.example.myapplication.R
import com.example.myapplication.dialog.DialogoCambiarPassword
import com.example.myapplication.dialog.DialogoFiltroUsuario
import com.example.myapplication.entities.Carrito
import com.example.myapplication.entities.Producto
import com.example.myapplication.fragments.FragmentCatalogoRopa
import com.example.myapplication.fragments.usuario.FragmentCarrito
import com.example.myapplication.fragments.usuario.FragmentCompraFinal
import com.example.myapplication.fragments.usuario.FragmentCompras
import com.example.myapplication.fragments.usuario.FragmentFiltroResultado
import com.example.myapplication.interfaces.*
import com.example.myapplication.utils.HelperUsuario
import com.example.myapplication.utils.Util
import com.example.myapplication.utils.Util.Companion.cambiarFragment
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.material.navigation.NavigationView
import java.time.LocalDate
import java.util.*
import kotlin.collections.ArrayList

class UsuarioActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener,
    MostrarFiltroUsuario, PasarDatosCompra, Refrescar4, AniadirCarrito, ReducirCarrito,
    AumentarCarrito {

    private lateinit var toolbar: Toolbar
    private lateinit var drawer: DrawerLayout
    private lateinit var navView: NavigationView
    private lateinit var bun: Bundle
    private lateinit var user: String
    private lateinit var pass: String
    private lateinit var helper: HelperUsuario
    private lateinit var fragment: Fragment
    private lateinit var nom: TextView
    private lateinit var ape: TextView
    private lateinit var mai: TextView
    private lateinit var carritoContador: TextView
    private lateinit var carritos: ArrayList<Carrito>
    private lateinit var icono: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        cargarIdioma()

        setContentView(R.layout.activity_usuario)
        carritos = ArrayList()

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawer = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        nom = findViewById(R.id.nav_nombre_usuario)
        ape = findViewById(R.id.nav_apellidos_usuario)
        mai = findViewById(R.id.nav_email_usuario)
        carritoContador = findViewById(R.id.nav_carrito_usuario)
        icono = findViewById(R.id.carrito_icono)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawer.addDrawerListener(toggle)
        toggle.syncState()
        navigationView.setNavigationItemSelectedListener(this)

    }

    override fun onResume() {
        super.onResume()


        val pref = PreferenceManager.getDefaultSharedPreferences(this)

        val nombre = pref.getString("nombrePrefUsuario", "")
        val apellidos = pref.getString("apellidosPrefUsuario", "")
        val email = pref.getString("emailPrefUsuario", "")


        nom.text = nombre
        ape.text = apellidos
        mai.text = email

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_preferencias, menu)

        return true

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {

            R.id.itemAjustes -> {

                val intencion = Intent(this, PreferenciasActivity::class.java)
                val extra = intent.extras?.getString("tipo")
                intencion.putExtra("tipo", extra)
                startActivity(intencion)

                true
            }

            R.id.itemSalir -> {

                startActivity(Intent(this, MainActivity::class.java))

                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    /**SELECCION DE PESTAÑA*/
    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        bun = intent.extras!!
        user = bun.getString("user")!!
        pass = bun.getString("pass")!!
        bun = Bundle()

        when (item.itemId) {
            R.id.item_catalogo_usuario -> {

                refrescar4(Util.USUARIO)

            }

            R.id.item_filtro_usuario -> {

                bun.putString("user", user)
                val dialogoFiltro = DialogoFiltroUsuario()
                dialogoFiltro.arguments = bun
                dialogoFiltro.show(supportFragmentManager, "dialogoFiltro")

            }

            R.id.item_compras_usuario -> {

                fragment =
                    FragmentCompras()
                bun.putString("user", user)
                fragment.arguments = bun
                val fragmentManager: FragmentManager = supportFragmentManager
                fragmentManager.beginTransaction()
                    .replace(R.id.fragment, fragment)
                    .addToBackStack(null)
                    .commit()

                drawer.closeDrawer(GravityCompat.START)

            }

            R.id.item_ubicacion_usuario -> {

                if (servicioCorrecto()) {
                    val intencion = Intent(this, MapsActivity::class.java)
                    startActivity(intencion)
                }

            }

            R.id.item_password_usuario -> {

                bun = intent.extras!!
                user = bun.getString("user")!!
                pass = bun.getString("pass")!!
                val dialogoCambiar = DialogoCambiarPassword()
                val args = Bundle()
                args.putString("user", user)
                args.putString("pass", pass)
                dialogoCambiar.arguments = args
                dialogoCambiar.show(supportFragmentManager, "dialogoCrear")

            }

            R.id.item_idiomas_usuario -> {


                val extra = intent.extras?.getString("tipo")
                val listItmes = arrayOf(
                    resources.getString(R.string.espaniol),
                    resources.getString(R.string.ingles)
                )

                val mBuilder = AlertDialog.Builder(this)
                mBuilder.setTitle(resources.getString(R.string.elige_idioma))
                mBuilder.setSingleChoiceItems(listItmes, -1) { dialog, which ->
                    if (which == 0) {
                        if (extra != null) {
                            cambiarIdioma("es")
                        }
                        recreate()
                    } else if (which == 1) {
                        if (extra != null) {
                            cambiarIdioma("en")
                        }
                        recreate()
                    }

                    dialog.dismiss()
                }
                val mDialog = mBuilder.create()

                mDialog.show()

            }

        }

        return true
    }

    /**
     * COMPROBACION DEL CORRECTO FUNCIONAMIENTO
     */
    private fun servicioCorrecto(): Boolean {

        val disponible = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this)
        when {
            disponible == ConnectionResult.SUCCESS -> {

                return true
            }
            GoogleApiAvailability.getInstance().isUserResolvableError(disponible) -> {

                val dialogo = GoogleApiAvailability.getInstance()
                    .getErrorDialog(this, disponible, Util.ERROR_DIALOG_REQUEST)
                dialogo.show()
            }
            else -> {
                Toast.makeText(
                    this,
                    resources.getString(R.string.peticiones_mapa),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        return false
    }

    /**INTERFAZ USUAURIO*/
    override fun mostrarFiltroUsuario(valor: String, opcion: String) {

        when (opcion) {

            Util.FILTRO_MARCA -> {

                val fragment =
                    FragmentFiltroResultado()

                helper = HelperUsuario()
                val productos: ArrayList<Producto> = helper.filtroMarcaProducto(valor)!!
                bun = Bundle()
                bun.putSerializable("filtro_marca", productos)
                bun.putString(Util.FILTRO_MARCA, "marca")
                bun.putString("user", user)

                fragment.arguments = bun
                val fragmentManager = supportFragmentManager
                fragmentManager.beginTransaction()
                    .replace(R.id.fragment, fragment)
                    .addToBackStack(null)
                    .commit()

                drawer.closeDrawer(GravityCompat.START)


            }

            Util.FILTRO_ANIO -> {

                val fragment =
                    FragmentFiltroResultado()

                val helper = HelperUsuario()
                val productos: ArrayList<Producto> = helper.filtroAnioProducto(valor)!!
                bun = Bundle()
                bun.putSerializable("filtro_anio", productos)
                bun.putString(Util.FILTRO_ANIO, "anio")
                bun.putString("user", user)

                fragment.arguments = bun
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.fragment, fragment)
                    .addToBackStack(null)
                    .commit()

                drawer.closeDrawer(GravityCompat.START)


            }

            Util.FILTRO_TALLA -> {

                val fragment =
                    FragmentFiltroResultado()

                helper = HelperUsuario()
                val productos: ArrayList<Producto> = helper.filtroTallaProducto(valor)!!
                val bun = Bundle()
                bun.putSerializable("filtro_talla", productos)
                bun.putString(Util.FILTRO_TALLA, "talla")
                bun.putString("user", user)

                fragment.arguments = bun
                val fragmentManager = supportFragmentManager
                fragmentManager.beginTransaction()
                    .replace(R.id.fragment, fragment)
                    .addToBackStack(null)
                    .commit()

                drawer.closeDrawer(GravityCompat.START)

            }

        }
    }

    override fun pasarDatosCompra(producto: Producto) {

        helper = HelperUsuario()
        val fecha = LocalDate.now()

        var boo = helper.comprarProducto(producto.idProducto, user, fecha.toString(), fecha.toString())

        if (!boo) {

            val boo2 = helper.reducirContadorProductos(producto.idProducto)

            if (!boo2) {

                Toast.makeText(
                    applicationContext, resources.getString(R.string.producto_comprado),
                    Toast.LENGTH_SHORT
                ).show()
                boo = helper.aumentarContadorCompras(user)

                if (boo) {

                    Toast.makeText(
                        applicationContext,
                        resources.getString(R.string.alcanzado_limite),
                        Toast.LENGTH_SHORT
                    ).show()

                }

            } else {

                Toast.makeText(
                    applicationContext,
                    resources.getString(R.string.error),
                    Toast.LENGTH_SHORT
                )
                    .show()

            }

        } else {

            Toast.makeText(
                applicationContext, resources.getString(R.string.alcanzado_limite),
                Toast.LENGTH_SHORT
            )
                .show()

        }


    }

    override fun refrescar4(tipo: Int) {


        fragment = FragmentCatalogoRopa()
        bun.putString("user", user)
        bun.putInt("tipo", Util.USUARIO)
        fragment.arguments = bun

        val fragmentManager = supportFragmentManager
        fragmentManager.beginTransaction()
            .replace(R.id.fragment, fragment)
            .addToBackStack(null)
            .commit()
        drawer.closeDrawer(GravityCompat.START)

        fragment = FragmentCatalogoRopa()
        bun.putInt("tipo", tipo)
        fragment.arguments = bun
        cambiarFragment(fragment, drawer)

    }


    fun cambiarIdioma(idioma: String) {

        val locale = Locale(idioma)
        Locale.setDefault(locale)
        val config = Configuration()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            config.setLocale(locale)
        }
        baseContext.resources.updateConfiguration(
            config,
            baseContext.resources.displayMetrics
        )
        val editor = PreferenceManager.getDefaultSharedPreferences(this).edit()
        editor.putString("idiomaUsuario", idioma)
        editor.apply()

    }


    fun cargarIdioma() {

        val pref = PreferenceManager.getDefaultSharedPreferences(this)
        val language = pref.getString("idiomaUsuario", "")
        if (language != null) {
            cambiarIdioma(language)
        }

    }

    override fun aniadirCarrito(producto: Producto) {

        var num = carritoContador.text.toString().toInt()
        carritoContador.text = "" + ++num

        if (carritos.isEmpty()) {

            carritos.add(Carrito(1, producto))

        } else {

            for (x in 0 until carritos.size) {

                if (carritos[x].producto == producto) {

                    if (carritos[x].cantidad!! < producto.cantidad) {

                        carritos[x].cantidad = (carritos[x].cantidad?.plus(1))

                        break

                    } else {

                        Toast.makeText(
                            this,
                            resources.getString(R.string.stock_disponible),
                            Toast.LENGTH_SHORT
                        ).show()
                        Toast.makeText(
                            this,
                            "${carritos[x].producto!!.cantidad} total",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }

                if (x == carritos.size.minus(1)) {
                    carritos.add(Carrito(1, producto))
                    //carritos[x].cantidad = (carritos[x].cantidad?.plus(1))
                    //carritoContador.text = ""+ ++num
                    break
                }
            }
        }

    }

    fun clickIcono(view: View) {
        if (carritos.isEmpty()) {
            Toast.makeText(this, resources.getString(R.string.carrito_vacio), Toast.LENGTH_LONG)
                .show();
        } else {
            val bun = Bundle()
            bun.putSerializable("carritos", carritos)
            val frag = FragmentCarrito()
            frag.arguments = bun

            val fragmentManager = supportFragmentManager
            fragmentManager.beginTransaction()
                .replace(R.id.fragment, frag)
                .addToBackStack(null)
                .commit()
            drawer.closeDrawers()
        }
    }

    override fun reducirCarrito(boo:Boolean) {

        if(boo==false) {

            if (carritoContador.text.toString().toInt() > 0) {
                carritoContador.text = carritoContador.text.toString().toInt().minus(1).toString()
            }

        }else {
            carritoContador.text = "0"
        }
    }

    override fun aumentarCarrito() {

        carritoContador.text = carritoContador.text.toString().toInt().plus(1).toString()


    }

}
