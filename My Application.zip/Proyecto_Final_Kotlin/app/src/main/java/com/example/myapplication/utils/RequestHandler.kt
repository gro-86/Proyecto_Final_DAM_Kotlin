package com.example.myapplication.utils

import android.util.Log
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.net.ssl.HttpsURLConnection

class RequestHandler {

    fun sendPostRequest(requestURL: String, postDataParams: HashMap<String, String>): String {

        val url: URL
        var sb = StringBuilder()
        try {
            url = URL(requestURL)

            val conn = url.openConnection() as HttpURLConnection

            conn.readTimeout = 15000
            conn.connectTimeout = 15000
            conn.requestMethod = "POST"
            conn.doInput = true
            conn.doOutput = true

            val os = conn.outputStream

            val writer = BufferedWriter(
                OutputStreamWriter(os, "UTF-8")
            )

            writer.write(getPostDataString(postDataParams))
            writer.flush()
            writer.close()
            os.close()

            val responseCode = conn.responseCode

            if (responseCode == HttpsURLConnection.HTTP_OK) {

                sb = StringBuilder()
                sb.append(conn.inputStream.bufferedReader().use(BufferedReader::readText))

            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return sb.toString()
    }

    fun sendGetRequest(requestURL: String): String {
        val sb = StringBuilder()
        try {

            val url = URL(requestURL)

            val con = url.openConnection() as HttpURLConnection

            sb.append(con.inputStream.bufferedReader().use(BufferedReader::readText))

        } catch (e: Exception) {
        }
        return sb.toString()
    }

    private fun getPostDataString(params: HashMap<String, String>): String {

        val result = StringBuilder()
        var first = true

        try {

            for ((key, value) in params) {
                if (first) first = false else result.append("&")
                result.append(URLEncoder.encode(key, "UTF-8"))
                result.append("=")
                result.append(URLEncoder.encode(value, "UTF-8"))
            }

            Log.i("TAG", result.toString())

        } catch (e: UnsupportedEncodingException) {
            e.printStackTrace()
        }

        return result.toString()

    }

}

