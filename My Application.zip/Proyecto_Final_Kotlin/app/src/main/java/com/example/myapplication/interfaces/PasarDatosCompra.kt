package com.example.myapplication.interfaces

import com.example.myapplication.entities.Producto

interface PasarDatosCompra {

    fun pasarDatosCompra(producto: Producto)
}