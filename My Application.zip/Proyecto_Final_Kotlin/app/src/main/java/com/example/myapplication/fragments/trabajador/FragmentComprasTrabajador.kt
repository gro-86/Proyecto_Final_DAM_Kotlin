package com.example.myapplication.fragments.trabajador

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.GridView
import android.widget.ListView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.myapplication.entities.Compra
import com.example.myapplication.R
import com.example.myapplication.interfaces.Refrescar
import com.example.myapplication.utils.AdapterCompras
import com.example.myapplication.utils.HelperTrabajador
import com.example.myapplication.utils.HelperUsuario

class FragmentComprasTrabajador : Fragment() {

    private lateinit var grid: GridView
    private lateinit var helper: HelperTrabajador
    private lateinit var helper2: HelperUsuario
    private var listener: Refrescar? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_compras_trabajador, container, false)
        grid = view.findViewById(R.id.gridComprasTrabajador) as GridView
        helper = HelperTrabajador()
        helper2 = HelperUsuario()

        if (helper.mostrarCompras() != null) {

            val compras = helper.mostrarCompras()!!
            val productos = helper2.mostrarProductosDisponibles()!!
            val adapter = AdapterCompras(view.context, 0, productos, compras)
            grid.adapter = adapter

        }

        when {
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) and
                    (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) -> {

                grid?.numColumns=2


            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) and
                    (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) -> {

                grid?.numColumns=1

            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) and
                    (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) -> {

                grid?.numColumns=1

            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) and
                    (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) -> {

                grid?.numColumns=2

            }
        }

        registerForContextMenu(grid)
        return view
    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menu.add(Menu.NONE, R.id.item_retrasar_entrega, Menu.NONE, resources.getString(R.string.retrasar_entrega))
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo

        val compra = grid.adapter.getItem(info.position) as Compra

        when (item.itemId) {

            R.id.item_retrasar_entrega -> {

                val boo = helper.retrasarEntrega(compra.idCompra)

                if (!boo) {

                    Toast.makeText(context, resources.getString(R.string.entrega_retrasada), Toast.LENGTH_SHORT)
                        .show()
                    listener?.refrescar()

                } else {

                    Toast.makeText(
                        context,
                        resources.getString(R.string.producto_entregado),
                        Toast.LENGTH_SHORT
                    ).show()

                }

            }

        }

        return super.onContextItemSelected(item)

    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if(context is Refrescar){
            listener = context
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener=null
    }

}