package com.example.myapplication.fragments

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.Toast.LENGTH_SHORT
import androidx.fragment.app.Fragment
import com.example.myapplication.R
import com.example.myapplication.activities.TrabajadorActivity
import com.example.myapplication.activities.UsuarioActivity
import com.example.myapplication.utils.HelperUsuario

class Login : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view = inflater.inflate(R.layout.fragment_login, container, false) as View
        val usuario = view.findViewById(R.id.edit_user_login) as EditText
        val contrasenia = view.findViewById(R.id.edit_password_registro) as EditText
        val boton = view.findViewById(R.id.btn_registro) as Button

        boton.setOnClickListener{

            if (TextUtils.isEmpty(usuario.text)) {
                usuario.error = resources.getString(R.string.falta_usuario)
            }

            if (TextUtils.isEmpty(contrasenia.text)) {
                contrasenia.error = resources.getString(R.string.falta_password)
            }

            if(usuario.text.isNotEmpty() && contrasenia.text.isNotEmpty()) {

                val helper = HelperUsuario()
                val md = helper.crearMD5(contrasenia.text.toString())
                val resultado = helper.buscarUsuario(usuario.text.toString(), md)

                if (resultado) {

                    val result = helper.esTrabajador(usuario.text.toString(), md)
                    if (result) {

                        val intencion = Intent(context, TrabajadorActivity::class.java)
                        intencion.putExtra("tipo","trabajador")
                        startActivity(intencion)
                        Toast.makeText(context, resources.getString(R.string.cuenta_trabajador), LENGTH_SHORT).show()

                    } else {

                        val intencion2 = Intent(context, UsuarioActivity::class.java)
                        intencion2.putExtra("tipo","usuario")
                        intencion2.putExtra("user", usuario.text.toString())
                        intencion2.putExtra("pass", md)
                        startActivity(intencion2)
                        Toast.makeText(context, resources.getString(R.string.cuenta_usuario), LENGTH_SHORT).show()
                    }


                } else {

                    view.let { Toast.makeText(context, resources.getString(R.string.usuario_no_encontrado), LENGTH_SHORT).show() }
                }

            }

        }

        return view

    }


}