package com.example.myapplication.utils

import android.graphics.Bitmap
import com.example.myapplication.entities.Compra
import com.example.myapplication.entities.Producto
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class HelperTrabajador {



    /**CREAR PRODUCTO*/
    fun crearProducto(
        producto: Producto, imagen: Bitmap
    ): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_producto"] = producto.idProducto
        params["marca"] = producto.marca
        params["modelo"] = producto.modelo
        params["precio"] = producto.precio.toString()
        params["anio_creacion"] = producto.anioCreacion.toString()
        params["foto"] = producto.foto
        params["id_proveedor_producto"] = producto.idProveedor.toString()
        params["talla"] = producto.talla
        params["cantidad"] = producto.cantidad.toString()
        params["imagen"] = imgToBase64(imagen)

        val request = PerformNetworkRequest(
            Util.URL_CREAR_PRODUCTO,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)

                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                return true
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return true
        }

    }

    //FALLA
    /**BUSCAR USER*/
    fun buscarUsuarioTrabajador(nombre: String): String {

        var user = ""
        val params: HashMap<String, String> = HashMap()
        params["nombre_usuario"] = nombre
        val request = PerformNetworkRequest(Util.URL_BUSCAR_USUARIO_TRABAJADOR, params, Util.CODE_POST_REQUEST)

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val usuariosJSON = objeto.getJSONArray("usuarios")

                    for (x in 0 until usuariosJSON.length()) {

                        val obj = usuariosJSON.getJSONObject(x)
                        user = obj.getString("user")

                    }

                }
            } catch (e: JSONException) {
                e.printStackTrace()

            }

        } catch (e: Exception) {
            e.printStackTrace()

        }

        return user
    }

    /**MOSTRAR COMPRAS PRODUCTO*/
    fun buscarIdProveedor(nombre: String): Int? {

        var idProveedor = -1
        val params: HashMap<String, String> = HashMap()
        params["nombre_proveedor"] = nombre
        val request = PerformNetworkRequest(
            Util.URL_BUSCAR_ID_PROVEEDOR_TRABAJADOR,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val proveedoresJSON = objeto.getJSONArray("proveedores")

                    for (x in 0 until proveedoresJSON.length()) {

                        val obj = proveedoresJSON.getJSONObject(x)
                        idProveedor = obj.getString("id_proveedor").toInt()

                    }

                } else return null
            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

        return idProveedor
    }

    /**MOSTRAR PROVEEDORES*/
    fun mostrarProveedores(): ArrayList<String>? {

        val proveedores: ArrayList<String> = ArrayList()
        val request = PerformNetworkRequest(
            Util.URL_MOSTRAR_PROVEEDORES_TRABAJADOR,
            null,
            Util.CODE_GET_REQUEST
        )
        try {

            val resultado = request.execute().get()

            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val proveedoresJSON = objeto.getJSONArray("proveedores")

                    for (i in 0 until proveedoresJSON.length()) {

                        val obj = proveedoresJSON.getJSONObject(i)

                        proveedores.add(obj.getString("nombre_proveedor"))
                    }

                } else {

                    return null
                }

            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

        return proveedores
    }

    /**MOSTRAR USUARIOS*/

    fun mostrarUsuarios(): ArrayList<String>? {

        val usuarios = ArrayList<String>()
        val request = PerformNetworkRequest(
            Util.URL_MOSTRAR_USUARIOS_TRABAJADOR,
            null,
            Util.CODE_GET_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val usuariosJSON = objeto.getJSONArray("usuarios")

                    for (x in 0 until usuariosJSON.length()) {

                        val obj = usuariosJSON.getJSONObject(x)
                        val nombreUsuario = obj.getString("nombre_usuario")

                        usuarios.add((nombreUsuario))

                    }
                    return usuarios
                } else return null
            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    /**MODIFICAR PRODUCTO*/
    fun modificarProducto(producto: Producto, imagen: Bitmap): Boolean {

        val params: HashMap<String, String> = HashMap()

        params["id_producto"] = producto.idProducto
        params["marca"] = producto.marca
        params["modelo"] = producto.modelo
        params["precio"] = producto.precio.toString()
        params["anio_creacion"] = producto.anioCreacion.toString()
        params["foto"] = producto.foto
        params["id_proveedor_producto"] = producto.idProveedor.toString()
        params["talla"] = producto.talla
        params["cantidad"] = producto.cantidad.toString()
        params["imagen"] = imgToBase64(imagen)

        val request = PerformNetworkRequest(
            Util.URL_MODIFICAR_PRODUCTO_TRABAJADOR,
            params,
            Util.CODE_POST_REQUEST
        )
        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {

                val objeto = JSONObject(resultado)
                !objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }

    }

    /**RETRASAR ENTREGA*/
    fun retrasarEntrega(id_compra: Int): Boolean {

        var variable =true
        val params: HashMap<String, String> = HashMap()
        params["id_compra"] = id_compra.toString()
        val request =
            PerformNetworkRequest(
                Util.URL_RETRASAR_ENTREGA_TRABAJADOR,
                params,
                Util.CODE_POST_REQUEST
            )


        try {

            val resultado = request.execute().get()

            request.cancel(true)

            try {
                val objeto = JSONObject(resultado)

                return objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()

            }

        } catch (e: Exception) {
            e.printStackTrace()

        }

        return variable
    }

    /**BORRAR PRODUCTO*/
    fun borrarProducto(idProducto: String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_producto"] = idProducto

        val request = PerformNetworkRequest(
            Util.URL_BORRAR_PRODUCTO,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()

            request.cancel(true)

            try {
                val objeto = JSONObject(resultado)

                return objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()

                return true
            }

        } catch (e: Exception) {
            e.printStackTrace()

            return true
        }

        return true
    }

    /**QUITAR FOREIGN*/
    fun quitarForeign(): Boolean {

        val request =
            PerformNetworkRequest(Util.URL_QUITAR_FOREIGN, null, Util.CODE_GET_REQUEST)

        try {

            val resultado = request.execute().get()

            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)
                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                true
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return true
        }

    }


    /**AGREGAR FOREIGN*/
    fun agregarForeign(): Boolean {

        val request =
            PerformNetworkRequest(Util.URL_AGREGAR_FOREIGN, null, Util.CODE_GET_REQUEST)

        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {

                val objeto = JSONObject(resultado)
                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
               return true
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return true
        }

    }

    fun mostrarCompras(): ArrayList<Compra>? {

        val compras = ArrayList<Compra>()
        val request = PerformNetworkRequest(
            Util.URL_MOSTRAR_COMPRAS,
            null,
            Util.CODE_GET_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val comprasJSON = objeto.getJSONArray("compras")

                    for (x in 0 until comprasJSON.length()) {

                        val obj = comprasJSON.getJSONObject(x)
                        val idProducto = obj.getString("id_producto_compra")
                        val inicio = obj.getString("fecha_compra")
                        val fin = obj.getString("fecha_entrega")
                        val hora = obj.getString("hora_compra")
                        val idCompra = obj.getString("id_compra").toInt()
                        val compra = Compra(idCompra, idProducto, inicio, fin, hora)

                        compras.add((compra))

                    }
                    return compras
                } else return null
            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    /**INSERTAR FOTO*/

    fun imgToBase64(bitmap: Bitmap): String {

        val out: ByteArrayOutputStream?
        lateinit var resultado: String

        try {
            out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, out)

            out.flush()
            out.close()

            val imgBytes: ByteArray = out.toByteArray()

            resultado = Base64.getEncoder().encodeToString(imgBytes)

        } catch (e: Exception) {
            e.printStackTrace()
        }

        return resultado
    }

}

