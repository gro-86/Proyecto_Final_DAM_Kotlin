package com.example.myapplication.entities

data class Usuario (var id:Int, var dni: String,var nombre:String, var user: String,
                    var pass:String,var trabajador: Boolean, var bloqueado:Boolean){


    constructor(dni: String, nombre:String, user: String, pass:String) : this(0,dni,nombre,user,pass,false,false){

        this.dni=dni
        this.nombre=nombre
        this.user=user
        this.pass=pass

    }







}