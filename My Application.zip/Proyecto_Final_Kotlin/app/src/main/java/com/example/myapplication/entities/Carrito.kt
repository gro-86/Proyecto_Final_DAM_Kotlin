package com.example.myapplication.entities

data class Carrito(var cantidad:Int?,var producto:Producto?) {


}