package com.example.myapplication.activities

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.size
import com.example.myapplication.R
import com.example.myapplication.fragments.Login
import com.example.myapplication.fragments.SignUp
import com.example.myapplication.utils.MyViewPagerAdapter
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adapter = MyViewPagerAdapter(
            supportFragmentManager
        )

        adapter.addFragment(Login(),resources.getString(R.string.tab_text_1))
        adapter.addFragment(SignUp(),resources.getString(R.string.tab_text_2))
        viewPager.adapter = adapter
        tabs.setupWithViewPager(viewPager)

    }

}