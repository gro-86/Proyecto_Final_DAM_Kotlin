package com.example.myapplication.interfaces

interface Refrescar4 {
    fun refrescar4(tipo:Int)
}