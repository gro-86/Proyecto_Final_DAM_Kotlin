package com.example.myapplication.dialog

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity.RESULT_OK
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.widget.*
import android.widget.Toast.LENGTH_SHORT
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import com.example.myapplication.R
import com.example.myapplication.entities.Producto
import com.example.myapplication.interfaces.Refrescar
import com.example.myapplication.interfaces.Refrescar2
import com.example.myapplication.utils.HelperTrabajador
import com.example.myapplication.utils.Util
import com.example.myapplication.utils.Util.Companion.IMAGEN_ELEGIDA
import com.example.myapplication.utils.Util.Companion.mostrarIndice
import com.squareup.picasso.Picasso

class DialogoModificar : DialogFragment() {

    private lateinit var helper: HelperTrabajador
    private lateinit var contexto: Context
    private lateinit var imagen: ImageView
    private lateinit var bitmap: Bitmap
    private var listener: Refrescar?=null
    private var listener2: Refrescar2?=null
    private var posicion:Int=-1
    private lateinit var tal: String


    @SuppressLint("InflateParams")
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val inflater = requireActivity().layoutInflater
        val builder = AlertDialog.Builder(activity)
        val vista = inflater.inflate(R.layout.dialogo_insertar_trabajador, null)
        builder.setView(vista)

        val talla = vista.findViewById<Spinner>(R.id.spinnerTalla)
        val proveedor = vista.findViewById<Spinner>(R.id.spinnerProveedor)
        val idProducto = vista.findViewById<EditText>(R.id.editIdProducto)
        val marca = vista.findViewById<EditText>(R.id.editMarca)
        val modelo = vista.findViewById<EditText>(R.id.editModelo)
        val anio = vista.findViewById<EditText>(R.id.editAnio)
        val precio = vista.findViewById<EditText>(R.id.editPrecio)
        val cantidad = vista.findViewById<EditText>(R.id.editCantidad)
        val nombreImagen = vista.findViewById<EditText>(R.id.editNombreArchivo)
        val titulo = vista.findViewById<TextView>(R.id.textTitulo)
        imagen = vista.findViewById(R.id.image_crear_trabajador)
        contexto = vista.context
        helper = HelperTrabajador()

        if(arguments!!.containsKey("clave")) {
            titulo.text = resources.getString(R.string.modificar)
        }

        val bun = arguments

        if (bun != null) {

            val producto = requireArguments().getSerializable("producto") as Producto

            idProducto.setText(producto.idProducto)
            marca.setText(producto.marca)
            modelo.setText(producto.modelo)
            anio.setText(producto.anioCreacion.toString())
            precio.setText(producto.precio.toString())
            cantidad.setText(producto.cantidad.toString())
            nombreImagen.setText(producto.foto)
            idProducto.isEnabled = false
            tal=producto.talla
            Picasso.get()
                .load("${Util.URL_IMAGES}${producto.foto}")
                .into(imagen)

        }

        helper = HelperTrabajador()
        val proveedores = helper.mostrarProveedores()
        val tallas = arrayOf("S", "M", "L", "XL")

        val adapter1 = proveedores?.let {
            ArrayAdapter(
                vista.context, R.layout.support_simple_spinner_dropdown_item, it
            )
        }

        val adapter2 =
            ArrayAdapter(vista.context, R.layout.support_simple_spinner_dropdown_item, tallas)

        if (proveedores != null) {
            proveedor.adapter = adapter1
        }

        talla.adapter = adapter2

        for(x in tallas.indices){


            if(talla.getItemAtPosition(x).toString()==tal) {

                posicion=x

            }

        }
        talla.setSelection(posicion)
        proveedor.setSelection(mostrarIndice(proveedor, proveedor.selectedItem.toString()))
        talla.setSelection(mostrarIndice(talla, talla.selectedItem.toString()))

        imagen.setOnClickListener {
            revisarPermisos()
        }

        builder.setPositiveButton(android.R.string.yes) { _, _ ->

            val tal = talla.selectedItem.toString()

            if (TextUtils.isEmpty(marca.text)) {
                marca.error = resources.getString(R.string.falta_marca)
                marca.requestFocus()
            }

            if (TextUtils.isEmpty(anio.text)) {
                anio.error = resources.getString(R.string.falta_anio)
                anio.requestFocus()
            }

            if (TextUtils.isEmpty(modelo.text)) {
                modelo.error = resources.getString(R.string.falta_modelo)
                modelo.requestFocus()
            }

            if (TextUtils.isEmpty(idProducto.text)) {
                idProducto.error = resources.getString(R.string.falta_id_producto)
                idProducto.requestFocus()
            }

            if (TextUtils.isEmpty(cantidad.text)) {
                cantidad.error = resources.getString(R.string.falta_cantidad)
                cantidad.requestFocus()
            }

            if (TextUtils.isEmpty(precio.text)) {
                precio.error = resources.getString(R.string.falta_precio)
                precio.requestFocus()
            }

            if (TextUtils.isEmpty(nombreImagen.text)) {
                nombreImagen.error = resources.getString(R.string.falta_ruta)
                nombreImagen.requestFocus()
            }

            if (imagen.drawable == null) {
                Toast.makeText(context, resources.getString(R.string.elija_imagen), LENGTH_SHORT).show()
            }

            if ((marca.text.toString().isNotEmpty() )&& (modelo.text.toString().isNotEmpty())&&(
                anio.text.toString().isNotEmpty()) && (idProducto.text.toString().isNotEmpty()) &&
                (cantidad.text.toString().isNotEmpty()) && (precio.text.isNotEmpty()) &&
                (nombreImagen.text.toString().isNotEmpty()) && (imagen.drawable != null)){

                if (helper.buscarIdProveedor(proveedor.selectedItem.toString()) != -1) {

                    val idProv = helper.buscarIdProveedor(proveedor.selectedItem.toString())

                    if (!Util.formatoAnio(anio.text.toString().toInt())) {
                        val producto = Producto(
                            idProducto.text.toString(),
                            marca.text.toString(),
                            modelo.text.toString(),
                            precio.text.toString().toDouble(),
                            anio.text.toString().toInt(),
                            nombreImagen.text.toString(),
                            idProv!!, tal,
                            cantidad.text.toString().toInt()
                        )

                        val boo = helper.modificarProducto(producto, bitmap)

                        if (!boo) {
                            Toast.makeText(
                                context,
                                resources.getString(R.string.producto_aniadido),
                                LENGTH_SHORT
                            ).show()

                            if (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) {


                                listener2!!.refrescar2()

                            } else if (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) {

                                listener!!.refrescar()

                            }


                        } else {
                            Toast.makeText(
                                context,
                                resources.getString(R.string.producto_no_aniadido),
                                LENGTH_SHORT
                            ).show()
                        }

                    }else {

                        Toast.makeText(
                            context,
                            resources.getString(R.string.formato_anio),
                            LENGTH_SHORT
                        ).show()

                    }

                }
            }
        }

        builder.setNegativeButton(android.R.string.no) { _, _ ->
            Toast.makeText(activity, resources.getString(R.string.cancelado), Toast.LENGTH_LONG).show()
        }

        return builder.create()

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (resultCode == RESULT_OK && requestCode == IMAGEN_ELEGIDA) {
            bitmap = data?.extras?.get("data") as Bitmap
            imagen.setImageBitmap(bitmap)
        }

    }

    private fun encenderCamara() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, IMAGEN_ELEGIDA)
    }

    private fun revisarPermisos() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_DENIED ||
            ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_DENIED
        ) {

            val permisos = arrayOf(
                Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            requestPermissions(permisos, Util.PERMISO_CODIGO)

        } else {
            encenderCamara()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        when (requestCode) {

            Util.PERMISO_CODIGO -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    encenderCamara()
                } else {
                    Toast.makeText(context, resources.getString(R.string.permiso_denegado), LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if(context is Refrescar){
            listener = context
        }

        if(context is Refrescar2){
            listener2 = context
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener=null
        listener2=null
    }
}