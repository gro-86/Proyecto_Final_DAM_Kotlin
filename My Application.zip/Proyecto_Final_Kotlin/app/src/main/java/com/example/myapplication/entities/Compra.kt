package com.example.myapplication.entities

import java.sql.Time

data class Compra (var idCompra:Int,var idProductoCompra: String, var idUsuarioCompra: Int,var fechaCompra:String,
var fechaEntrega:String,private var entregada: Boolean, var hora_compra: String
) {

    constructor(idCompra:Int,idProductoCompra:String,idUsuarioCompra: Int, fechaCompra:String,fechaEntrega: String,hora_compra: String) : this(idCompra,idProductoCompra,idUsuarioCompra,fechaCompra,fechaEntrega,false,hora_compra){

        this.idCompra=idCompra
        this.idProductoCompra=idProductoCompra
        this.idUsuarioCompra=idUsuarioCompra
        this.fechaCompra=fechaCompra
        this.fechaEntrega=fechaEntrega
        this.hora_compra=hora_compra

    }

    constructor(idCompra:Int,idProductoCompra:String,fechaCompra:String,fechaEntrega: String,hora_compra: String) : this(idCompra,idProductoCompra,0,fechaCompra,fechaEntrega,false,hora_compra){

        this.idCompra=idCompra
        this.idProductoCompra=idProductoCompra
        this.fechaCompra=fechaCompra
        this.fechaEntrega=fechaEntrega
        this.hora_compra=hora_compra

    }

}