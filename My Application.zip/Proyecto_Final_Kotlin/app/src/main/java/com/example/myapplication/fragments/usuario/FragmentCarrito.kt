package com.example.myapplication.fragments.usuario

import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.myapplication.R
import com.example.myapplication.entities.Carrito
import com.example.myapplication.interfaces.AumentarCarrito
import com.example.myapplication.interfaces.PasarDatosCompra
import com.example.myapplication.interfaces.ReducirCarrito
import com.example.myapplication.utils.AdapterCarrito
import com.example.myapplication.utils.HelperUsuario
import kotlin.math.roundToLong

class FragmentCarrito: Fragment() {

    private lateinit var grid: GridView
    private lateinit var precio: TextView
    private lateinit var  carritos: ArrayList<Carrito>
    private lateinit var adaptador: AdapterCarrito
    private var listener: ReducirCarrito? = null
    private var listener2: AumentarCarrito? = null
    private var listener3: PasarDatosCompra? = null
    private var total = 0.0

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_carrito, container, false) as View
        grid = view.findViewById(R.id.grid_carrito)
        precio = view.findViewById(R.id.text_total_carrito)
        val boton = view.findViewById(R.id.btn_comprar_carrito) as Button

        carritos = ArrayList()
        total = 0.0

        if (arguments?.getSerializable("carritos") != null) {

                carritos = arguments?.getSerializable("carritos") as ArrayList<Carrito>
        }

        for (x in 0 until carritos.size){

            total = total.plus((carritos[x].cantidad?.toDouble())!!* (carritos[x].producto?.precio)!!)

        }

        adaptador =  AdapterCarrito(view.context,R.layout.item_carrito, carritos)

        grid.adapter=adaptador
        precio.text="Total: ${(total * 100.0).roundToLong() / 100.0}€"

        boton.setOnClickListener{

            if(carritos.isEmpty()){

                Toast.makeText(view.context,resources.getString(R.string.carrito_vacio),Toast.LENGTH_SHORT).show()

            }else {

                var boo=false
                val helper = HelperUsuario()
                for(x in 0 until carritos.size) {

                    if ((carritos[x].cantidad)!! > (helper.cantidadProductos(carritos[x].producto!!.idProducto))) {

                        boo=true
                        Toast.makeText(view.context,resources.getString(R.string.exceso)+" ${carritos[x].producto!!.cantidad} (${carritos[x].producto!!.marca} - ${carritos[x].producto!!.talla} )",Toast.LENGTH_SHORT).show()

                        break
                    }

                }

                if(!boo){

                    for (x in 0 until carritos.size){

                        for (y in 0 until carritos[x].cantidad!!) {

                            listener3?.pasarDatosCompra(carritos[x].producto!!)

                        }

                    }

                    listener?.reducirCarrito(true)
                    carritos.removeAll(carritos)
                    adaptador.notifyDataSetChanged()
                    precio.text = "Total: ${0}€"

                }

            }

        }

        registerForContextMenu(grid)

        return view
    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)

        menu.add(Menu.NONE, R.id.item_reducir_carrito, Menu.NONE, resources.getString(R.string.reducir))
        menu.add(Menu.NONE, R.id.item_aumentar_carrito, Menu.NONE, resources.getString(R.string.aumentar))

    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        val carrito: Carrito = grid.adapter.getItem(info.position) as Carrito

        when (item.itemId) {

            R.id.item_reducir_carrito -> {

                if(carrito.cantidad!! >1){

                    for (x in 0 until carritos.size){

                        if(carrito.cantidad!!>0) {
                            listener?.reducirCarrito(false)
                            carrito.cantidad= carrito.cantidad!!.minus(1)
                            grid.invalidateViews()
                            total -= carrito.producto?.precio!!
                            precio.text = "Total: ${(total * 100.0).roundToLong() / 100.0}€"
                        }

                        break
                    }

                }else if (carrito.cantidad==1){

                    for(x in 0 until carritos.size){
                        if(carritos[x].producto?.idProducto==carrito.producto!!.idProducto){

                            total -= carrito.producto?.precio!!
                            carritos.remove(carrito)
                            adaptador.notifyDataSetChanged()


                            precio.text = "Total: ${(total * 100.0).roundToLong() / 100.0}€"

                            listener?.reducirCarrito(false)

                            break
                        }
                    }
                }

            }

            R.id.item_aumentar_carrito -> {

                    if((carrito.cantidad!!>=0) && (carrito.producto?.cantidad!!>carrito.cantidad!!)) {
                        listener2?.aumentarCarrito()
                        if(carrito.cantidad!! <=carrito.producto!!.cantidad) {
                            carrito.cantidad = carrito.cantidad!!.plus(1)
                            grid.invalidateViews()
                            total += carrito.producto?.precio!!
                            precio.text = "Total: ${(total * 100.0).roundToLong() / 100.0}€"
                        }
                    }else {
                        Toast.makeText(view?.context,resources.getString(R.string.stock_disponible),Toast.LENGTH_SHORT).show()
                        Toast.makeText(view?.context,"${carrito.producto!!.cantidad} total",Toast.LENGTH_SHORT).show()
                    }


            }

        }

        return super.onContextItemSelected(item)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if(context is ReducirCarrito){
            listener= context
        }

        if(context is AumentarCarrito){
            listener2= context
        }

        if(context is PasarDatosCompra){
            listener3= context
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        listener = null
        listener2 = null
        listener3=null
    }

}