package com.example.myapplication.interfaces

interface ComunicarFiltro {
    fun comunicarFiltro(informacion:String)
}