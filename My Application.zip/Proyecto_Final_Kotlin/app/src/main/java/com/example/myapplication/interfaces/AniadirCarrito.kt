package com.example.myapplication.interfaces

import com.example.myapplication.entities.Producto

interface AniadirCarrito {
    fun aniadirCarrito(producto: Producto)
}