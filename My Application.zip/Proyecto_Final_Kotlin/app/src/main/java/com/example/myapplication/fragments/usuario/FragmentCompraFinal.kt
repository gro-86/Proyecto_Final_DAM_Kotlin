package com.example.myapplication.fragments.usuario

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.Toast.LENGTH_SHORT
import androidx.fragment.app.Fragment
import com.example.myapplication.R
import com.example.myapplication.entities.Producto
import com.example.myapplication.utils.HelperUsuario
import com.example.myapplication.utils.Util
import com.squareup.picasso.Picasso
import java.time.LocalDate

class FragmentCompraFinal : Fragment() {

    var user = ""
    private lateinit var producto: Producto
    private var boo = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_compra_final, container, false) as View
        val imagen = view.findViewById(R.id.imagen_final) as ImageView
        val helper = HelperUsuario()
        val comprar = view.findViewById(R.id.btnComprar) as Button
        val cantidad = arrayListOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
        val spinner = view.findViewById<Spinner>(R.id.spinner_final)

        val bun: Bundle = requireArguments()
        for (key in bun.keySet()) {

            if (key == "producto") {

                producto = bun.getSerializable("producto") as Producto


            } else if (key == "user") {

                user = bun.getString("user").toString()

            }

        }


        Picasso.get()
            .load("${Util.URL_IMAGES}${producto.foto}")
            .into(imagen)



        val adaptador = ArrayAdapter(view.context!!, android.R.layout.simple_spinner_item, cantidad)
        spinner.adapter = adaptador

        comprar.setOnClickListener {

            boo = helper.numeroCompras(user)

            if(!boo){

                val fecha = LocalDate.now()
                val numero = spinner.selectedItem as Int

                for (x in 1..numero) {

                    boo = helper.comprarProducto(producto.idProducto, user, fecha.toString(),fecha.toString())

                    if (!boo) {

                        val boo2 = helper.reducirContadorProductos(producto.idProducto)

                        if (!boo2) {

                            Toast.makeText(context, resources.getString(R.string.producto_comprado), LENGTH_SHORT).show()
                            boo = helper.aumentarContadorCompras(user)

                            if (boo) {

                                Toast.makeText(
                                    context,
                                    resources.getString(R.string.alcanzado_limite),
                                    LENGTH_SHORT
                                ).show()

                            }

                        } else {

                            Toast.makeText(context, resources.getString(R.string.error), LENGTH_SHORT)
                                .show()

                        }

                    } else {

                        Toast.makeText(context, resources.getString(R.string.alcanzado_limite), LENGTH_SHORT)
                        .show()

                    }

                }

            }else {

                Toast.makeText(context, resources.getString(R.string.alcanzado_limite), LENGTH_SHORT)
                    .show()

            }

        }

        return view
    }

}