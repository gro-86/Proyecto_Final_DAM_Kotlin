package com.example.myapplication.interfaces

interface MostrarFiltroUsuario {

    fun mostrarFiltroUsuario(valor:String, opcion: String)

}