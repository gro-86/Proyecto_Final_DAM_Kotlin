package com.example.myapplication.interfaces

interface Refrescar2 {
    fun refrescar2()
}