package com.example.myapplication.interfaces

interface PasarInformacionFiltro {

    fun pasarInformacionFiltro(nombre:String,refresh:Boolean)

}