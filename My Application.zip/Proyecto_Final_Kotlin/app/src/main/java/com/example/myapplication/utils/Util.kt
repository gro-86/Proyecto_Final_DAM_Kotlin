package com.example.myapplication.utils

import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.isDigitsOnly
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.example.myapplication.R
import java.util.*

class Util {

    companion object {

        //OTROS
        const val USUARIO = 1
        const val TRABAJADOR = 2
        const val PERMISO_CODIGO = 1
        const val IMAGEN_ELEGIDA = 1
        const val CLAVE_PRODUCTO = "producto"
        const val FILTRO_TALLA = "talla"
        const val FILTRO_MARCA = "marca"
        const val FILTRO_ANIO = "anio"
        const val FILTRO_NOMBRE = "nombre"
        const val ERROR_DIALOG_REQUEST = 9001
        const val CODE_GET_REQUEST = 1
        const val CODE_POST_REQUEST = 2
        private const val ROOT_URL = "http://192.168.1.5/app-kotlin/Api.php?apicall="
        //private const val ROOT_URL = "http://192.168.1.102/app-kotlin/Api.php?apicall="

        //URL WEBSERVICE REGISTRO/LOGIN
        const val URL_CREAR_USUARIO = ROOT_URL + "crearUsuario"
        const val URL_BUSCAR_USUARIO = ROOT_URL + "buscarUsuario"
        const val URL_ES_TRABAJADOR = ROOT_URL + "esTrabajador"

        //URL Imagenes
        const val URL_IMAGES = "http://192.168.1.5/app-kotlin/"
        //const val URL_IMAGES = "http://192.168.1.102/app-kotlin/"

        //USUARIO
        const val URL_MOSTRAR_PRODUCTOS_DISPONIBLES = ROOT_URL + "mostrarProductosDisponibles"
        const val URL_MOSTRAR_COMPRAS_USUARIO = ROOT_URL + "mostrarComprasUsuario"
        const val URL_MOSTRAR_COMPRAS = ROOT_URL + "mostrarCompras"
        const val URL_COMPRAR_PRODUCTO = ROOT_URL + "comprarProducto"
        const val URL_AUMENTAR_CONTADOR = ROOT_URL + "aumentarContadorCompras"
        const val URL_REDUCIR_CONTADOR = ROOT_URL + "reducirContadorCompras"
        const val URL_REDUCIR_PRODUCTOS = ROOT_URL + "reducirContadorProductos"
        const val URL_NUMERO_COMPRAS = ROOT_URL + "numeroCompras"
        const val URL_ESTA_DEVUELTO = ROOT_URL + "estaDevuelto"
        const val URL_CANTIDAD_PRODUCTO = ROOT_URL + "cantidadProductos"
        const val URL_COMPROBAR_TIEMPO = ROOT_URL + "comprobarTiempo"
        const val URL_BUSCAR_ID_USUARIO = ROOT_URL + "buscarIdUsuario"
        const val URL_DEVOLVER_PRODUCTO = ROOT_URL + "devolverProducto"
        const val URL_CAMBIAR_PASSWORD = ROOT_URL + "cambiarPassword"
        const val URL_FILTRO_MARCA_PRODUCTO = ROOT_URL + "filtroMarcaProducto"
        const val URL_FILTRO_TALLA_PRODUCTO = ROOT_URL + "filtroTallaProducto"
        const val URL_FILTRO_ANIO_PRODUCTO = ROOT_URL + "filtroAnioProducto"
        const val URL_HAY_STOCK = ROOT_URL + "hayStock"

        //TRABAJADOR
        const val URL_MOSTRAR_PROVEEDORES_TRABAJADOR = ROOT_URL + "mostrarProveedores"
        const val URL_MOSTRAR_USUARIOS_TRABAJADOR = ROOT_URL + "mostrarUsuarios"
        const val URL_BUSCAR_ID_PROVEEDOR_TRABAJADOR = ROOT_URL + "buscarIdProveedor"
        const val URL_BUSCAR_USUARIO_TRABAJADOR = ROOT_URL + "buscarUsuarioTrabajador"
        const val URL_MODIFICAR_PRODUCTO_TRABAJADOR = ROOT_URL + "modificarProducto"
        const val URL_RETRASAR_ENTREGA_TRABAJADOR = ROOT_URL + "retrasarEntrega"
        const val URL_BORRAR_PRODUCTO = ROOT_URL + "borrarProducto"
        const val URL_QUITAR_FOREIGN = ROOT_URL + "quitarForeign"
        const val URL_CREAR_PRODUCTO = ROOT_URL + "crearProducto"
        const val URL_AGREGAR_FOREIGN = ROOT_URL + "agregarForeign"


        fun AppCompatActivity.cambiarFragment(fragment: Fragment, drawer: DrawerLayout) {

            val fragmentManager = supportFragmentManager
            fragmentManager.beginTransaction()
                .replace(R.id.fragment, fragment)
                .addToBackStack(null)
                .commit()
            drawer.closeDrawers()

        }

        fun AppCompatActivity.cambiarFragment2(fragment: Fragment) {

            val fragmentManager = supportFragmentManager
            fragmentManager.beginTransaction()
                .replace(R.id.fragment, fragment)
                .addToBackStack(null)
                .commit()


        }

        fun mostrarIndice(spin: Spinner, texto: String): Int {

            for (x in 0 until spin.count) {

                if (spin.getItemAtPosition(x).toString().equals(texto, ignoreCase = true)) {
                    return x
                }
            }

            return 0
        }

        fun formatoDni(dni: String): Boolean {

            var boo = false
            if ((!dni.isDigitsOnly()) && (dni.length == 9)) {

                if ((dni[0].isDigit()) &&
                    (dni[1].isDigit()) &&
                    (dni[2].isDigit()) &&
                    (dni[3].isDigit()) &&
                    (dni[4].isDigit()) &&
                    (dni[5].isDigit()) &&
                    (dni[6].isDigit()) &&
                    (dni[7].isDigit()) &&
                    (dni[dni.length - 1].isLetter())

                    || ((dni[0].isLetter()) &&
                            (dni[1].isDigit()) &&
                            (dni[2].isDigit()) &&
                            (dni[3].isDigit()) &&
                            (dni[4].isDigit()) &&
                            (dni[5].isDigit()) &&
                            (dni[6].isDigit()) &&
                            (dni[7].isDigit()) &&
                            (dni[dni.length - 1].isLetter()))
                ) {
                    boo = true
                }

            }

            return boo
        }


        fun formatoPassword(pass: String, user: String): Boolean {

            var boo = false
            if ((contieneLetrasNumeros(pass)) && ((pass != user) && (pass.length >= 7))) {

                boo = true
            }

            return boo
        }

        fun formatoAnio(anio:Int): Boolean {

            var boo= true

            if((anio <= Calendar.getInstance().get(Calendar.YEAR)) && anio>=1970){

                boo=false
            }

            return boo
        }

        fun contieneLetrasNumeros(pass: String): Boolean {

            var boo = false
            val patron = Regex("\\S*(\\S*([a-zA-Z]\\S*[0-9])|([0-9]\\S*[a-zA-Z]))\\S*")

                if (patron.containsMatchIn(pass)) {

                    boo = true

                }


            return boo
        }

    }

}