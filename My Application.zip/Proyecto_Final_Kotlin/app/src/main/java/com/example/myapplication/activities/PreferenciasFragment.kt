package com.example.myapplication.activities


import android.os.Bundle
import androidx.preference.PreferenceFragmentCompat
import com.example.myapplication.R


class PreferenciasFragment: PreferenceFragmentCompat()  {


    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {

        //setPreferencesFromResource(R.xml.preferencias_trabajador,rootKey)
        when (arguments?.getString("tipo")) {

            "usuario" -> {

                addPreferencesFromResource(R.xml.preferencias_usuario)
                //setPreferencesFromResource(R.xml.preferencias_usuario,rootKey)

            }

            "trabajador" -> {

                addPreferencesFromResource(R.xml.preferencias_trabajador)
                //setPreferencesFromResource(R.xml.preferencias_trabajador,rootKey)
            }
        }

        //activity?.setTheme(android.R.style.Theme_Holo);


    }


}