package com.example.myapplication.fragments

import android.content.Context
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.Toast.LENGTH_SHORT
import androidx.fragment.app.Fragment
import com.example.myapplication.entities.Usuario
import com.example.myapplication.R
import com.example.myapplication.interfaces.MostrarFiltroUsuario
import com.example.myapplication.utils.HelperUsuario
import com.example.myapplication.utils.Util.Companion.formatoDni
import com.example.myapplication.utils.Util.Companion.formatoPassword

class SignUp : Fragment(){

    private var listener: MostrarFiltroUsuario? = null
    private lateinit var registrar: Button
    private var contexto: Context? = null
    private var helper: HelperUsuario? = null
    private lateinit var dni: EditText
    private lateinit var nombre: EditText
    private lateinit var user: EditText
    private lateinit var password: EditText
    private lateinit var confirmacion: EditText

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view = inflater.inflate(R.layout.fragment_signup, container, false) as View
        contexto = view.context
        dni = view.findViewById(R.id.edit_dni_registro)
        nombre = view.findViewById(R.id.edit_nombre_registro)
        user = view.findViewById(R.id.edit_user_login)
        password = view.findViewById(R.id.edit_password_registro)
        confirmacion = view.findViewById(R.id.edit_confirmar_registro)
        registrar = view.findViewById(R.id.btn_registro) as Button
        registrar.setOnClickListener {

            helper = HelperUsuario()

            if (TextUtils.isEmpty(nombre.text)) {
                nombre.error = resources.getString(R.string.falta_nombre)
                nombre.requestFocus()
            }

            if(TextUtils.isEmpty(dni.text)){
                dni.error=resources.getString(R.string.dni_vacio)
                dni.requestFocus()
            }

            if (TextUtils.isEmpty(user.text)) {
                user.error = resources.getString(R.string.falta_usuario)
                user.requestFocus()
            }

            if (TextUtils.isEmpty(password.text)) {
                password.error = resources.getString(R.string.falta_password)
                password.requestFocus()
            }

            if (TextUtils.isEmpty(confirmacion.text)) {
                confirmacion.error = resources.getString(R.string.falta_confirmacion)
                confirmacion.requestFocus()
            }

            if (confirmacion.text.toString() != password.text.toString()) {
                confirmacion.error = resources.getString(R.string.no_coincide)
            }

            if ((nombre.text.toString().isNotEmpty()) && (dni.text.toString().isNotEmpty()) &&
                (password.text.toString().isNotEmpty()) && (confirmacion.text.toString().isNotEmpty()) &&
                confirmacion.text.toString() == password.text.toString()) {

                if(formatoPassword(password.text.toString(),user.text.toString()) &&
                    formatoDni(dni.text.toString())) {

                    val md = helper!!.crearMD5(password.text.toString())
                    val resultado = helper!!.crearUsuario(
                        Usuario(
                            dni.text.toString(),
                            nombre.text.toString(),
                            user.text.toString(),
                            md)
                    )

                    if (!resultado) {

                        Toast.makeText(
                            context,
                            resources.getString(R.string.usuario_registrado),
                            LENGTH_SHORT
                        ).show()
                        nombre.setText("")
                        user.setText("")
                        password.setText("")
                        confirmacion.setText("")
                        dni.setText("")

                    } else {

                        Toast.makeText(context, resources.getString(R.string.error), LENGTH_SHORT)
                            .show()
                    }

                } else if (!formatoPassword(password.text.toString(),user.text.toString())){

                    Toast.makeText(context, resources.getString(R.string.formato_pass), LENGTH_SHORT)
                        .show()

                }else if (!formatoDni(dni.text.toString())){

                    Toast.makeText(context, resources.getString(R.string.formato_dni), LENGTH_SHORT)
                        .show()

                }else {

                    Toast.makeText(context, resources.getString(R.string.fallo_ambos), LENGTH_SHORT)
                        .show()

                }

            }

        }

        return view
    }

}