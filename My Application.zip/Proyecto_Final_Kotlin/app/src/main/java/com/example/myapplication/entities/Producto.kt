package com.example.myapplication.entities

import java.io.Serializable



data class Producto (var idProducto: String,
                     var marca:String,
                     var modelo:String,
                     var precio: Double,
                     var anioCreacion: Int,
                     var foto: String,
                     var idProveedor:Int,
                     var talla: String,
                     var cantidad:Int):Serializable {

    constructor(idProducto: String,
                marca:String,
                modelo:String,
                precio: Double,
                foto: String,
                talla: String,
                cantidad: Int

                 ) : this(idProducto,marca,modelo,precio,0,foto,0,talla, cantidad){

        this.idProducto=idProducto
        this.marca=marca
        this.modelo=modelo
        this.precio=precio
        this.foto=foto
        this.talla=talla
        this.cantidad=cantidad

    }



}