package com.example.myapplication.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import com.example.myapplication.R
import com.example.myapplication.entities.Carrito
import com.squareup.picasso.Picasso

class AdapterCarrito(private var contexto: Context, private var recurso:Int, private var listaCarritos
: ArrayList<Carrito>):  ArrayAdapter<Carrito>(contexto,recurso,listaCarritos) {

    @SuppressLint("ViewHolder", "SetTextI18n")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val inflater = LayoutInflater.from(contexto)
        val view = inflater.inflate(recurso,null)

        val idProducto = view.findViewById(R.id.id_item_carrito) as TextView
        val marca = view.findViewById(R.id.marca_item_carrito) as TextView
        val modelo = view.findViewById(R.id.modelo_item_carrito) as TextView
        val precio = view.findViewById(R.id.precio_item_carrito) as TextView
        val cantidad = view.findViewById(R.id.unidades_item_carrito) as TextView
        val talla = view.findViewById(R.id.talla_item_carrito) as TextView
        val imagen = view.findViewById(R.id.imagen_item_carrito) as ImageView


        val type: Typeface? = ResourcesCompat.getFont(contexto, R.font.cinzel_bold)
        idProducto.typeface = type
        marca.typeface = type
        modelo.typeface = type
        cantidad.typeface = type
        precio.typeface = type
        talla.typeface = type


        if(view.resources.configuration.screenLayout and
            Configuration.SCREENLAYOUT_SIZE_MASK ==
            Configuration.SCREENLAYOUT_SIZE_XLARGE){

            idProducto.textSize= 30F
            marca.textSize= 30F
            cantidad.textSize= 30F
            modelo.textSize= 30F
            precio.textSize= 30F
            talla.textSize= 30F
            imagen.maxWidth=190
            imagen.maxHeight=190

        }

        val producto: Carrito = listaCarritos[position]
        idProducto.text = producto.producto?.idProducto
        modelo.text = producto.producto?.modelo
        marca.text = producto.producto?.marca
        talla.text = producto.producto?.talla
        cantidad.text =  producto.cantidad.toString()
        precio.text = "${producto.producto?.precio}€"



        Picasso.get()
            .load("${Util.URL_IMAGES}${listaCarritos[position].producto?.foto}")
            .into(imagen)

        return view

    }

}