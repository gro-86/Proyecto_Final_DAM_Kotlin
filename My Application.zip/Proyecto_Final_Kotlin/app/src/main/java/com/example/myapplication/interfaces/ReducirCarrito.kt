package com.example.myapplication.interfaces

interface ReducirCarrito {
    fun reducirCarrito(boo:Boolean)
}