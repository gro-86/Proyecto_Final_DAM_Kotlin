package com.example.myapplication.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.view.*
import android.widget.*
import androidx.core.content.res.ResourcesCompat
import com.example.myapplication.entities.Compra
import com.example.myapplication.R
import com.example.myapplication.entities.Producto
import com.squareup.picasso.Picasso

class AdapterCompras(
    var contexto: Context, recurso:Int, var productos: ArrayList<Producto>, var compras: ArrayList<Compra>) :
    ArrayAdapter<Compra>(contexto,recurso,compras) {

    @SuppressLint("InflateParams", "ViewHolder", "SetTextI18n")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        var x = 0
        var found = 0
        var marca = ""
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.item_compra_usuario,null)

        val idProducto = view.findViewById(R.id.item_id_producto_compra) as TextView
        val compra = view.findViewById(R.id.item_fecha_compra) as TextView
        val entrega = view.findViewById(R.id.item_fecha_entrega)  as TextView
        val idUsuarioCompra = view.findViewById(R.id.item_id_usuario_compra) as TextView
        val hora = view.findViewById(R.id.item_tiempo_compra) as TextView
        val idCompra = view.findViewById(R.id.item_id_compra) as TextView
        val imagen = view.findViewById(R.id.item_imagen_compra) as ImageView

        if((view.resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) ) {

            idProducto.textSize=30F
            compra.textSize=30F
            entrega.textSize=30F
            idUsuarioCompra.textSize=30F
            hora.textSize=30F
            idCompra.textSize=30F
            imagen.maxHeight=190
            imagen.maxWidth=190

        }

        val comprax : Compra =compras[position]

        while(found<1){

            if (productos[x].idProducto == comprax.idProductoCompra) {

                marca = contexto.resources.getString(R.string.marca)+" " + productos[x].marca
                Picasso.get()
                    .load("${Util.URL_IMAGES}${productos[x].foto}")
                    .into(imagen)
                found=1

            } else {

                x++

            }

        }

        val type: Typeface? = ResourcesCompat.getFont(contexto, R.font.cinzel_bold)
        idProducto.typeface = type
        compra.typeface = type
        entrega.typeface = type
        idUsuarioCompra.typeface = type
        hora.typeface = type
        idCompra.typeface = type

        idProducto.text = marca
        compra.text=contexto.resources.getString(R.string.fecha_compra)+" "+ compras[position].fechaCompra
        entrega.text = contexto.resources.getString(R.string.fecha_entrega)+" "+ compras[position].fechaEntrega
        idUsuarioCompra.text= "${compras[position].idUsuarioCompra}"
        hora.text=contexto.resources.getString(R.string.hora)+" "+compras[position].hora_compra
        idCompra.text="${compras[position].idCompra}"

        return view
    }


}