package com.example.myapplication.activities

import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.preference.PreferenceManager
import com.example.myapplication.entities.Usuario
import com.example.myapplication.R
import com.example.myapplication.dialog.DialogoInsertarTrabajador
import com.example.myapplication.fragments.FragmentCatalogoRopa
import com.example.myapplication.fragments.trabajador.FragmentComprasTrabajador
import com.example.myapplication.fragments.trabajador.FragmentFiltro
import com.example.myapplication.fragments.trabajador.FragmentFiltroTrabajador
import com.example.myapplication.fragments.usuario.FragmentCompras
import com.example.myapplication.interfaces.*
import com.example.myapplication.utils.Util
import com.example.myapplication.utils.Util.Companion.cambiarFragment
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import java.util.*


class TrabajadorActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener,
    RetrasarEntrega,PasarInformacionFiltro,ComunicarFiltro,Refrescar,Refrescar2,Refrescar3{

    private lateinit var toolbar: Toolbar
    private lateinit var drawer: DrawerLayout
    private lateinit var navView: NavigationView
    private lateinit var fragment: Fragment
    private lateinit var bun: Bundle
    private lateinit var nom:TextView
    private lateinit var ape:TextView
    private lateinit var mai:TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        cargarIdioma()
        setContentView(R.layout.activity_trabajador)

        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        navView = findViewById(R.id.nav_view)
        drawer = findViewById(R.id.drawer_layout)

        nom=findViewById(R.id.nav_nombre)
        ape=findViewById(R.id.nav_apellidos)
        mai=findViewById(R.id.nav_email)

        val boton = findViewById<FloatingActionButton>(R.id.botonFloating)
        boton.setOnClickListener {

            val dialogoCrear = DialogoInsertarTrabajador()
            val bun = Bundle()
            bun.putString("clave",resources.getString(R.string.insertar))
            dialogoCrear.arguments=bun
            dialogoCrear.show(supportFragmentManager, "dialogoCrear")

        }

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawer.addDrawerListener(toggle)
        toggle.syncState()
        navigationView.setNavigationItemSelectedListener(this)

    }

    override fun onResume() {
        super.onResume()

        val pref = PreferenceManager.getDefaultSharedPreferences(this)

        val nombre = pref.getString("nombrePrefTrabajador","")
        val apellidos = pref.getString("apellidosPrefTrabajador","")
        val email = pref.getString("emailPrefTrabajador", "")

        nom.text=nombre
        ape.text=apellidos
        mai.text= email



    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_preferencias, menu)

        return true

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {

            R.id.itemAjustes -> {


                var intencion = Intent(this,PreferenciasActivity::class.java)
                val extra = intent.extras?.getString("tipo")
                intencion.putExtra("tipo",extra)
                startActivity(intencion)

                true
            }

            R.id.itemSalir -> {

                startActivity(Intent(this,MainActivity::class.java))

                true
            }

            else ->  super.onOptionsItemSelected(item)
        }

    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        val id = item.itemId
        bun = Bundle()
        drawer = findViewById(R.id.drawer_layout)

        when (id) {

            R.id.item_compras_trabajador -> {

                fragment = FragmentComprasTrabajador()
                cambiarFragment(fragment, drawer)

            }
            R.id.item_filtro_trabajador -> {

                fragment = FragmentFiltro()
                cambiarFragment(fragment, drawer)

            }

            R.id.item_catalogo_trabajador -> {
                fragment = FragmentCatalogoRopa()
                bun.putInt("tipo", Util.TRABAJADOR)
                fragment.arguments = bun
                cambiarFragment(fragment, drawer)
            }
            R.id.item_idiomas_trabajador -> {

                val lista = arrayOf(resources.getString(R.string.espaniol),resources.getString(R.string.ingles))

                val mBuilder = AlertDialog.Builder(this)
                mBuilder.setTitle(resources.getString(R.string.elige_idioma))
                mBuilder.setSingleChoiceItems(lista, -1) { dialog, which ->
                    if (which == 0) {
                        cambiarIdioma("es")
                        recreate()
                    } else if (which == 1) {
                        cambiarIdioma("en")
                        recreate()
                    }

                    dialog.dismiss()
                }
                val mDialog = mBuilder.create()

                mDialog.show()

            }
        }

        return true
    }

    override fun retrasarEntrega(usuarios: ArrayList<Usuario>) {

        val fragment = FragmentFiltroTrabajador()
        val bun = Bundle()
        bun.putSerializable("usuarios", usuarios)
        fragment.arguments = bun
        cambiarFragment(fragment, drawer)

    }

    override fun pasarInformacionFiltro(nombre: String,refresh:Boolean) {
        val fragment = FragmentCompras()
        val bun = Bundle()
        bun.putString("nombre", nombre)
        fragment.arguments = bun
        cambiarFragment(fragment, drawer)

    }

    override fun comunicarFiltro(nombre: String) {

        val fragment = FragmentCompras()
        val bun = Bundle()
        bun.putString("nombre", nombre)
        fragment.arguments = bun
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_filtro_final,fragment)
            .commit()

    }

    override fun refrescar() {
        val fragmentManager = supportFragmentManager
        fragmentManager.beginTransaction().detach(fragment).attach(fragment).commit()

    }

    override fun refrescar2() {

        fragment = FragmentCatalogoRopa()
        val bun = Bundle()
        bun.putInt("tipo", Util.TRABAJADOR)
        fragment.arguments = bun
        cambiarFragment(fragment, drawer)

    }

    override fun refrescar3() {

        fragment = FragmentFiltro()
        //fragment.arguments = bun
        cambiarFragment(fragment, drawer)

    }

    fun cambiarIdioma(idioma:String){

        val locale = Locale(idioma)
        Locale.setDefault(locale)
        val config = Configuration()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            config.setLocale(locale)
        }
        baseContext.resources.updateConfiguration(
            config,
            baseContext.resources.displayMetrics
        )
        val editor = PreferenceManager.getDefaultSharedPreferences(this).edit()
        editor.putString("idiomaTrabajador", idioma)
        editor.apply()

    }


    fun cargarIdioma() {

        val pref = PreferenceManager.getDefaultSharedPreferences(this)
        var language = pref.getString("idiomaTrabajador", "")
        if (language != null) {
            cambiarIdioma(language)
        }

    }

}
