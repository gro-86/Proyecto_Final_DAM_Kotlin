package com.example.myapplication.activities

import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentManager
import com.example.myapplication.R

class PreferenciasActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preferencias)

        val bundl=intent.extras?.getString("tipo")
        val bun = Bundle()
        bun.putString("tipo",bundl)
        val fragment = PreferenciasFragment()
        fragment.arguments=bun

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.container, fragment)
            .commit()
        /*
        supportFragmentManager.addOnBackStackChangedListener {
            FragmentManager.OnBackStackChangedListener{
                supportFragmentManager
                    .beginTransaction()
                    .remove(PreferenciasFragment())
                    .commit();
            }
        }

         */
    }
}