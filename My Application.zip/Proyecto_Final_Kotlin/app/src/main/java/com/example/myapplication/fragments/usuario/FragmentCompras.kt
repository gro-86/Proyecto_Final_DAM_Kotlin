package com.example.myapplication.fragments.usuario

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.GridView
import android.widget.Toast
import android.widget.Toast.LENGTH_SHORT
import androidx.fragment.app.Fragment
import com.example.myapplication.entities.Compra
import com.example.myapplication.R
import com.example.myapplication.interfaces.PasarInformacionFiltro
import com.example.myapplication.interfaces.Refrescar3
import com.example.myapplication.utils.AdapterCompras
import com.example.myapplication.utils.HelperTrabajador
import com.example.myapplication.utils.HelperUsuario

class FragmentCompras : Fragment() {

    private lateinit var grid: GridView
    private lateinit var bundle: Bundle
    private lateinit var helper: HelperUsuario
    private lateinit var helper2: HelperTrabajador
    private var listener: PasarInformacionFiltro? = null
    private var listener2: Refrescar3?=null
    private lateinit var user :String
    private lateinit var nombre:String

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_compras, container, false)
        grid = view.findViewById(R.id.gridComprasUsuario) as GridView
        helper = HelperUsuario()
        helper2 = HelperTrabajador()
        bundle = requireArguments()

        if (bundle.containsKey("nombre")) {

            user = requireArguments().getString("nombre")!!
            nombre=user
            user = helper2.buscarUsuarioTrabajador(user)

        } else if (bundle.containsKey("user")) {

            user = requireArguments().getString("user")!!

        }

        val compras = helper.mostrarCompras(user)!!
        val productos = helper.mostrarProductosDisponibles()!!
        val adaptador = AdapterCompras(view.context, 0, productos, compras)

        if (helper.mostrarCompras(user) != null) {

            grid.adapter = adaptador

        }


        when {
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) and
                    (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) -> {

                grid.numColumns=1


            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) and
                    (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) -> {

                grid.numColumns =1

            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) and
                    (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) -> {

                grid.numColumns=1

            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) and
                    (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) -> {

                grid.numColumns=1

            }
        }

        registerForContextMenu(grid)
        return view
    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)

        if (bundle.containsKey("nombre")) {

            menu.add(Menu.NONE, R.id.item_retrasar_entrega, Menu.NONE, resources.getString(R.string.retrasar_entrega))

        } else if (bundle.containsKey("user")) {

            menu.add(Menu.NONE, R.id.item_devolver_usuario, Menu.NONE, resources.getString(R.string.devolver))

        }

    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo

        val compra = grid.adapter.getItem(info.position) as Compra

        when (item.itemId) {

            R.id.item_devolver_usuario -> {

                helper = HelperUsuario()

                var boo = helper.comprobarTiempo(compra.idCompra)

                if (!boo) {

                    boo = helper.estaDevuelto(compra.idProductoCompra)

                    if (!boo) {

                        boo = helper.devolverProducto(compra.idCompra,compra.idProductoCompra)

                        if (!boo) {

                            boo = helper.reducirContadorCompras(compra.idUsuarioCompra)

                            if (!boo) {

                                Toast.makeText(context, resources.getString(R.string.producto_devuelto), LENGTH_SHORT)
                                    .show()

                            }

                        } else {

                            Toast.makeText(context, resources.getString(R.string.producto_no_devuelto), LENGTH_SHORT)
                                .show()

                        }

                    } else {

                        Toast.makeText(context, resources.getString(R.string.producto_entregado), LENGTH_SHORT)
                            .show()

                    }

                } else {

                    Toast.makeText(
                        context,
                        resources.getString(R.string.producto_enviado),
                        LENGTH_SHORT
                    ).show()

                }

            }

            R.id.item_retrasar_entrega -> {

                val boo = helper2.retrasarEntrega(compra.idCompra)

                if (!boo) {

                    Toast.makeText(context, resources.getString(R.string.entrega_retrasada), LENGTH_SHORT).show()

                    if (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) {

                        listener2?.refrescar3()


                    } else if (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) {

                        listener?.pasarInformacionFiltro(nombre,true)

                    }


                } else {

                    Toast.makeText(
                        context,
                        resources.getString(R.string.producto_entregado), LENGTH_SHORT
                    ).show()

                }

            }

        }

        return super.onContextItemSelected(item)

    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if(context is PasarInformacionFiltro) {
            listener = context
        }

        if(context is Refrescar3) {
            listener2 = context
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        listener = null
        listener2= null
    }

}