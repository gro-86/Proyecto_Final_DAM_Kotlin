package com.example.myapplication.interfaces

interface Refrescar3 {
    fun refrescar3()
}