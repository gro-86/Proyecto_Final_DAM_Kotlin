package com.example.myapplication.interfaces

import com.example.myapplication.entities.Usuario

interface RetrasarEntrega {

    fun retrasarEntrega(usuarios:ArrayList<Usuario>)

}