package com.example.myapplication.utils

import com.example.myapplication.entities.Compra
import com.example.myapplication.entities.Producto
import com.example.myapplication.entities.Usuario
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException

class HelperUsuario {

    /**CREAR MD5*/
    fun crearMD5(s: String): String {

        val md5 = "MD5"
        try {

            val digest: MessageDigest = MessageDigest
                .getInstance(md5)
            digest.update(s.toByteArray())
            val messageDigest: ByteArray = digest.digest()

            val hexString = StringBuilder()
            for (aMessageDigest in messageDigest) {

                var h = Integer.toHexString(0xFF and aMessageDigest.toInt())

                while (h.length < 2) {

                    h = "0$h"
                }
                hexString.append(h)
            }
            return hexString.toString()

        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        }
        return ""

    }

    /**CREAR USUARIO*/
    fun crearUsuario(usu: Usuario): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["dni"] = usu.dni
        params["nombre_usuario"] = usu.nombre
        params["user"] = usu.user
        params["pass"] = usu.pass

        val request = PerformNetworkRequest(
            Util.URL_CREAR_USUARIO,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()

            request.cancel(true)

            return try {

                val objeto = JSONObject(resultado)

                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**SABER SI ES TRABAJADOR O NO*/
    fun esTrabajador(user: String, pass: String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["user"] = user
        params["pass"] = pass
        val request =
            PerformNetworkRequest(
                Util.URL_ES_TRABAJADOR,
                params,
                Util.CODE_POST_REQUEST
            )

        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {

                val objeto = JSONObject(resultado)
                !objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    //HAY STOCK
    fun hayStock(id_producto:String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_producto"] = id_producto

        val request =
            PerformNetworkRequest(
                Util.URL_HAY_STOCK,
                params,
                Util.CODE_POST_REQUEST
            )

        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {

                val objeto = JSONObject(resultado)
                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**BUSCAR USUARIO*/
    fun buscarUsuario(user: String, password: String): Boolean {

        val params: HashMap<String, String> = HashMap()

        params["user"] = user
        params["pass"] = password
        val request =
            PerformNetworkRequest(
                Util.URL_BUSCAR_USUARIO,
                params,
                Util.CODE_POST_REQUEST
            )

        try {

            val resultado = request.execute().get()

            request.cancel(true)
            return try {

                val objeto = JSONObject(resultado)

                !objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }

    }

    /**CAMBIAR PASSWORD*/
    fun cambiarPassword(pass: String, user: String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["pass"] = pass
        params["user"] = user
        val request = PerformNetworkRequest(
            Util.URL_CAMBIAR_PASSWORD,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()

            request.cancel(true)

            return try {

                val objeto = JSONObject(resultado)

                !objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }

    }

    /**COMPRAR PRODUCTO*/
    fun comprarProducto(
        id_producto_compra: String,
        user: String,
        fecha1: String,
        fecha2: String
    ): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_producto_compra"] = id_producto_compra
        params["user"] = user
        params["fecha_compra"] = fecha1
        params["fecha_entrega"] = fecha2

        val request = PerformNetworkRequest(
            Util.URL_COMPRAR_PRODUCTO,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)

                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                return false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }

    }

    /**AUMENTAR CONTADOR*/
    fun aumentarContadorCompras(user: String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["user"] = user

        val request = PerformNetworkRequest(
            Util.URL_AUMENTAR_CONTADOR,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)

                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**REDUCIR CONTADOR*/
    fun reducirContadorCompras(id_usuario: Int): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_usuario_compra"] = id_usuario.toString()

        val request = PerformNetworkRequest(
            Util.URL_REDUCIR_CONTADOR,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)

                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**REDUCIR CONTADOR*/
    fun reducirContadorProductos(id_producto: String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_producto"] = id_producto

        val request = PerformNetworkRequest(
            Util.URL_REDUCIR_PRODUCTOS,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)

                objeto.getBoolean("error")

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**MOSTRAR PELICULAS DISPONIBLES*/
    fun mostrarProductosDisponibles(): ArrayList<Producto>? {
        val productos: ArrayList<Producto> = ArrayList()
        val request = PerformNetworkRequest(
            Util.URL_MOSTRAR_PRODUCTOS_DISPONIBLES,
            null,
            Util.CODE_GET_REQUEST
        )
        try {

            val resultado: String = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                return if (!objeto.getBoolean("error")) {

                    val productosJSON = objeto.getJSONArray("productos")

                    for (i in 0 until productosJSON.length()) {

                        val obj = productosJSON.getJSONObject(i)

                        productos.add(
                            Producto(
                                obj.getString("id_producto"),
                                obj.getString("marca"),
                                obj.getString("modelo"),
                                obj.getDouble("precio"),
                                obj.getInt("anio_creacion"),
                                obj.getString("foto"),
                                obj.getInt("id_proveedor_producto"),
                                obj.getString("talla"),
                                obj.getInt("cantidad")
                            )
                        )

                    }
                    productos
                } else null
            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    /**MOSTRAR COMPRAS PRODUCTO*/
    fun mostrarCompras(user: String): ArrayList<Compra>? {

        val compras = ArrayList<Compra>()
        val params: HashMap<String, String> = HashMap()
        params["user"] = user
        val request = PerformNetworkRequest(
            Util.URL_MOSTRAR_COMPRAS_USUARIO,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val comprasJSON = objeto.getJSONArray("compras")

                    for (x in 0 until comprasJSON.length()) {

                        val obj = comprasJSON.getJSONObject(x)
                        val idProducto = obj.getString("id_producto_compra")
                        val inicio = obj.getString("fecha_compra")
                        val fin = obj.getString("fecha_entrega")
                        val hora = obj.getString("hora_compra")
                        val idCompra = obj.getString("id_compra").toInt()
                        val idUsuario = buscarIdUsuario(user)
                        val compra = Compra(idCompra,idProducto, idUsuario!!, inicio, fin, hora)

                        compras.add((compra))

                    }
                    return compras
                } else return null
            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    /**CANTIDAD DE PRODUCTOS*/
    fun cantidadProductos(id_producto:String): Int {

        var cantidad=-1
        val params: HashMap<String, String> = HashMap()
        params["id_producto"] = id_producto

        val request = PerformNetworkRequest(
            Util.URL_CANTIDAD_PRODUCTO,
            params,
            Util.CODE_POST_REQUEST
        )


        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val productosJSON = objeto.getJSONArray("productos")

                    for (x in 0 until productosJSON.length()) {

                        val obj = productosJSON.getJSONObject(x)
                        cantidad = obj.getInt("cantidad")

                    }
                    return cantidad

                }

            } catch (e: JSONException) {
                e.printStackTrace()

            }

        } catch (e: Exception) {
            e.printStackTrace()

        }

        return cantidad
    }

    /**NUMERO COMPRAS*/
    fun numeroCompras(user: String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["user"] = user
        val request =
            PerformNetworkRequest(Util.URL_NUMERO_COMPRAS, params, Util.CODE_POST_REQUEST)
        val res: Boolean
        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)

                res = objeto.getBoolean("error")

                return res

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**COMPROBAR TIEMPO*/
    fun comprobarTiempo(id_compra: Int): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_compra"] = id_compra.toString()
        val request =
            PerformNetworkRequest(Util.URL_COMPROBAR_TIEMPO, params, Util.CODE_POST_REQUEST)
        val res: Boolean
        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)

                res = objeto.getBoolean("error")

                return res

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**DEVOLVER PRODUCTO*/
    fun devolverProducto(id_compra: Int,id_producto_compra: String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_compra"] = id_compra.toString()
        params["id_producto_compra"] = id_producto_compra
        val request =
            PerformNetworkRequest(Util.URL_DEVOLVER_PRODUCTO, params, Util.CODE_POST_REQUEST)
        val res: Boolean
        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {
                val objeto = JSONObject(resultado)

                res = objeto.getBoolean("error")

                return res

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**ESTA DEVUELTO*/
    fun estaDevuelto(id_producto_compra: String): Boolean {

        val params: HashMap<String, String> = HashMap()
        params["id_producto_compra"] = id_producto_compra
        val request =
            PerformNetworkRequest(Util.URL_ESTA_DEVUELTO, params, Util.CODE_POST_REQUEST)
        val res: Boolean
        try {

            val resultado = request.execute().get()
            request.cancel(true)

            return try {

                val objeto = JSONObject(resultado)

                res = objeto.getBoolean("error")

                return res

            } catch (e: JSONException) {
                e.printStackTrace()
                false
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**MOSTRAR COMPRAS PRODUCTO*/
    fun buscarIdUsuario(user: String): Int? {

        var idUsuario = -1
        val params: HashMap<String, String> = HashMap()
        params["user"] = user
        val request = PerformNetworkRequest(
            Util.URL_BUSCAR_ID_USUARIO,
            params,
            Util.CODE_POST_REQUEST)

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val usuariosJSON = objeto.getJSONArray("usuarios")

                    for (x in 0 until usuariosJSON.length()) {

                        val obj = usuariosJSON.getJSONObject(x)
                        idUsuario = obj.getString("id_usuario").toInt()

                    }

                } else return null
            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

        return idUsuario
    }

    /**FILTRO AÑO PRODUCTO*/
    fun filtroAnioProducto(anio: String): ArrayList<Producto>? {

        val productos: ArrayList<Producto> = ArrayList()
        val params: HashMap<String, String> = HashMap()
        params["anio_creacion"] = anio
        val request = PerformNetworkRequest(
            Util.URL_FILTRO_ANIO_PRODUCTO,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val productosJSON: JSONArray = objeto.getJSONArray("productos")

                    for (i in 0 until productosJSON.length()) {

                        val obj = productosJSON.getJSONObject(i)
                        val idProducto = obj.getString("id_producto")
                        val marca = obj.getString("marca")
                        val modelo = obj.getString("modelo")
                        val precio = obj.getString("precio").toDouble()
                        val talla = obj.getString("talla")
                        val foto = obj.getString("foto")
                        val cantidad = obj.getString("cantidad").toInt()
                        val producto = Producto(idProducto, marca, modelo, precio, foto, talla,cantidad)

                        productos.add(producto)

                    }
                    return productos

                } else return null

            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

    }

    /**FILTRO TALLA PRODUCTO*/
    fun filtroTallaProducto(talla: String): ArrayList<Producto>? {

        val productos: ArrayList<Producto> = ArrayList()
        val params: HashMap<String, String> = HashMap()
        params["talla"] = talla
        val request = PerformNetworkRequest(
            Util.URL_FILTRO_TALLA_PRODUCTO,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val productosJSON: JSONArray = objeto.getJSONArray("productos")

                    for (i in 0 until productosJSON.length()) {

                        val obj = productosJSON.getJSONObject(i)
                        val idProducto = obj.getString("id_producto")
                        val marca = obj.getString("marca")
                        val modelo = obj.getString("modelo")
                        val precio = obj.getString("precio").toDouble()
                        val talla = obj.getString("talla")
                        val foto = obj.getString("foto")
                        val cantidad = obj.getString("cantidad").toInt()
                        val producto = Producto(idProducto, marca, modelo, precio, foto, talla,cantidad)

                        productos.add(producto)

                    }
                    return productos

                } else return null

            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

    }

    /**FILTRO MARCA PRODUCTO*/
    fun filtroMarcaProducto(marca: String): ArrayList<Producto>? {

        val productos: ArrayList<Producto> = ArrayList()
        val params: HashMap<String, String> = HashMap()
        params["marca"] = marca
        val request = PerformNetworkRequest(
            Util.URL_FILTRO_MARCA_PRODUCTO,
            params,
            Util.CODE_POST_REQUEST
        )

        try {

            val resultado = request.execute().get()
            request.cancel(true)
            try {
                val objeto = JSONObject(resultado)

                if (!objeto.getBoolean("error")) {

                    val productosJSON: JSONArray = objeto.getJSONArray("productos")

                    for (i in 0 until productosJSON.length()) {

                        val obj = productosJSON.getJSONObject(i)
                        val idProducto = obj.getString("id_producto")
                        val marca = obj.getString("marca")
                        val modelo = obj.getString("modelo")
                        val talla = obj.getString("talla")
                        val foto = obj.getString("foto")
                        val precio = obj.getString("precio").toDouble()
                        val cantidad = obj.getString("cantidad").toInt()

                        val producto = Producto(idProducto, marca, modelo, precio, foto, talla,cantidad)

                        productos.add(producto)

                    }
                    return productos

                } else return null

            } catch (e: JSONException) {
                e.printStackTrace()
                return null
            }

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

    }

}