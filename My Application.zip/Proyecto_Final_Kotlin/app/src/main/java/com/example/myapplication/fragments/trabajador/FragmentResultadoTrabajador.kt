package com.example.myapplication.fragments.trabajador

import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.myapplication.entities.Compra
import com.example.myapplication.R
import com.example.myapplication.entities.Producto
import com.example.myapplication.utils.AdapterCompras
import com.example.myapplication.utils.HelperTrabajador
import com.example.myapplication.utils.HelperUsuario

class FragmentResultadoTrabajador : Fragment() {

    private lateinit var lista: ListView
    private lateinit var compras: ArrayList<Compra>
    private lateinit var productos: ArrayList<Producto>
    private lateinit var helper: HelperUsuario
    private lateinit var helper2: HelperTrabajador
    private lateinit var usuario: String


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_filtro_trabajador, container, false)
        val lista = view.findViewById<ListView>(R.id.gridView_fragment_filtro_resultado)
        helper = HelperUsuario()
        helper2 = HelperTrabajador()
        val bun: Bundle? = arguments

        if (bun != null) {

            productos = helper.mostrarProductosDisponibles()!!
            val nombre = bun.getString("nombre")!!
            usuario = helper2.buscarUsuarioTrabajador(nombre)

        }

        if ((helper.mostrarProductosDisponibles()!= null) && (helper.mostrarCompras(usuario)!= null)) {
            compras =  helper.mostrarCompras(usuario)!!
            val adapter = AdapterCompras(view.context, 0, productos, compras)
            lista.adapter = adapter

        }

        registerForContextMenu(lista)

        return view
    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menu.add(Menu.NONE, R.id.item_retrasar_entrega, Menu.NONE, "Retrasar entrega")

    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo

        val compra = lista.adapter.getItem(info.position) as Compra


        when (item.itemId) {

            R.id.item_retrasar_entrega -> {

                val boo = helper2.retrasarEntrega(compra.idCompra)

                if (!boo) {

                    Toast.makeText(context, "Entrega retrasada 7 días", Toast.LENGTH_SHORT)
                        .show()

                } else {

                    Toast.makeText(
                        context,
                        "Lo siento, el producto ya se había entregado",
                        Toast.LENGTH_SHORT
                    ).show()

                }

            }
        }

        return super.onContextItemSelected(item)
    }

}