package com.example.myapplication.fragments

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.GridView
import androidx.fragment.app.Fragment
import com.example.myapplication.R
import com.example.myapplication.dialog.DialogoBorrar
import com.example.myapplication.dialog.DialogoModificar
import com.example.myapplication.entities.Producto
import com.example.myapplication.interfaces.PasarDatosCompra
import com.example.myapplication.interfaces.AniadirCarrito
import com.example.myapplication.utils.AdapterProducto
import com.example.myapplication.utils.HelperTrabajador
import com.example.myapplication.utils.HelperUsuario
import com.example.myapplication.utils.Util
import com.example.myapplication.utils.Util.Companion.CLAVE_PRODUCTO

class FragmentCatalogoRopa : Fragment() {

    private var grid: GridView? = null
    private lateinit var helper: HelperUsuario
    private lateinit var helper2: HelperTrabajador
    private var listener: PasarDatosCompra? = null
    private var listener2: AniadirCarrito? = null
    private lateinit var contexto:Context
    private lateinit var adaptador:AdapterProducto
    private lateinit var productos: ArrayList<Producto>
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.activity_catalogo_ropa, container, false) as View
        grid = view.findViewById(R.id.gridCatalogoUsuario)
        helper = HelperUsuario()
        productos = helper.mostrarProductosDisponibles()!!
        contexto=view.context


        when {
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) and
                    (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) -> {

                grid?.numColumns=2


            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) and
                    (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) -> {

                grid?.numColumns=1

            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) and
                    (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) -> {

                grid?.numColumns=1

            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) and
                    (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) -> {

                grid?.numColumns=2

            }
        }


        if (!productos.isNullOrEmpty()) {

            adaptador = AdapterProducto(view.context, R.layout.item_catalogo_usuario, productos)
            grid!!.adapter = adaptador

        }

        registerForContextMenu(grid!!)

        return view
    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)

        when (arguments?.getInt("tipo")) {

            Util.USUARIO -> {
                menu.add(Menu.NONE, R.id.item_aniadir_usuario, Menu.NONE, resources.getString(R.string.aniadir_carrito))
            }

            Util.TRABAJADOR -> {
                menu.add(Menu.NONE, R.id.item_modificar_trabajador, Menu.NONE, resources.getString(R.string.modificar))
                menu.add(Menu.NONE, R.id.item_eliminar_trabajador, Menu.NONE, resources.getString(R.string.eliminar))

            }
        }

    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        val producto: Producto = grid!!.adapter.getItem(info.position) as Producto

        when (item.itemId) {

            R.id.item_aniadir_usuario -> {

                listener2?.aniadirCarrito(producto)

            }

            R.id.item_modificar_trabajador -> {

                val bun = Bundle()
                bun.putSerializable(CLAVE_PRODUCTO, producto)
                bun.putString("clave",resources.getString(R.string.insertar))
                val dialogoModificar = DialogoModificar()
                dialogoModificar.arguments = bun
                dialogoModificar.show(requireActivity().supportFragmentManager, "dialogoFiltro")

            }

            R.id.item_eliminar_trabajador -> {

                helper2 = HelperTrabajador()
                helper2.borrarProducto(producto.idProducto)
                val dialogoBorrar = DialogoBorrar()
                val bun = Bundle()
                bun.putSerializable(CLAVE_PRODUCTO, producto)
                dialogoBorrar.arguments = bun
                dialogoBorrar.show(requireActivity().supportFragmentManager, "dialogoEliminar")

            }

        }

        return super.onContextItemSelected(item)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is PasarDatosCompra) {

            listener = context

        }

        if(context is AniadirCarrito){

            listener2= context

        }

    }

    override fun onDetach() {
        super.onDetach()

        listener = null
        listener2=null
    }


}
