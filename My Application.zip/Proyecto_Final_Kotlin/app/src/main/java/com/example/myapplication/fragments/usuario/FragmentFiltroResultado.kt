package com.example.myapplication.fragments.usuario

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.GridView
import androidx.fragment.app.Fragment
import com.example.myapplication.entities.Producto
import com.example.myapplication.R
import com.example.myapplication.interfaces.AniadirCarrito
import com.example.myapplication.utils.AdapterProducto
import com.example.myapplication.utils.Util

class FragmentFiltroResultado : Fragment() {

    private var grid: GridView? = null
    private lateinit var productos: ArrayList<Producto>
    private lateinit var bundle: Bundle
    private var listener: AniadirCarrito? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_filtro_resultado, container, false)
        grid = view.findViewById(R.id.gridView_fragment_filtro_resultado)
        bundle = requireArguments()
        @Suppress("UNCHECKED_CAST")

        for (key in bundle.keySet()) {

            when (bundle.get(key)) {

                Util.FILTRO_MARCA -> {
                    productos =
                        bundle.getSerializable("filtro_marca") as ArrayList<Producto>
                }
                Util.FILTRO_ANIO -> {
                    productos =
                        bundle.getSerializable("filtro_anio") as ArrayList<Producto>
                }
                Util.FILTRO_TALLA -> {
                    productos =
                        bundle.getSerializable("filtro_talla") as ArrayList<Producto>

                }

                Util.FILTRO_NOMBRE -> {
                    productos =
                        bundle.getSerializable("filtro_nombre") as ArrayList<Producto>

                }
            }
        }

        if (!productos.isNullOrEmpty()) {

            val adaptador = AdapterProducto(view.context, R.layout.item_catalogo_usuario, productos)
            grid!!.adapter = adaptador

        }

        when {
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) and
                    (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) -> {

                grid?.numColumns=2


            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_NORMAL) and
                    (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) -> {

                grid?.numColumns=1

            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) and
                    (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) -> {

                grid?.numColumns=1

            }
            (resources.configuration.screenLayout and
                    Configuration.SCREENLAYOUT_SIZE_MASK ==
                    Configuration.SCREENLAYOUT_SIZE_XLARGE) and
                    (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) -> {

                grid?.numColumns=2

            }
        }

        registerForContextMenu(grid!!)

        return view
    }

    override fun onCreateContextMenu(
        menu: ContextMenu,
        v: View,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menu.add(Menu.NONE, R.id.item_aniadir_usuario, Menu.NONE, resources.getString(R.string.aniadir_carrito))
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        val producto: Producto = grid!!.adapter.getItem(info.position) as Producto

        when (item.itemId) {

            R.id.item_aniadir_usuario -> {

                listener?.aniadirCarrito(producto)

            }

        }

        return super.onContextItemSelected(item)

    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is AniadirCarrito) {

            listener = context

        }

    }

    override fun onDetach() {
        super.onDetach()

        listener = null
    }


}