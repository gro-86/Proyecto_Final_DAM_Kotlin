package com.example.myapplication.dialog

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.text.TextUtils
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.example.myapplication.R
import com.example.myapplication.interfaces.MostrarFiltroUsuario
import com.example.myapplication.interfaces.Refrescar4
import com.example.myapplication.utils.Util.Companion.USUARIO
import okhttp3.internal.Util


class DialogoFiltroUsuario : DialogFragment() {

    private var listener: MostrarFiltroUsuario? = null
    private var listener2: Refrescar4? = null

    @SuppressLint("InflateParams")
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        super.onCreate(savedInstanceState)
        val inflater = requireActivity().layoutInflater
        val builder = AlertDialog.Builder(activity)
        val view = inflater.inflate(R.layout.activity_dialogo_filtro_usuario, null)
        val grupo = view.findViewById(R.id.grupoUsuario) as RadioGroup
        val valor = view.findViewById(R.id.editFiltro) as EditText

        grupo.setOnCheckedChangeListener { _, _ ->
            if(grupo.checkedRadioButtonId==R.id.radioNada){

                valor.isEnabled=false
                Toast.makeText(view.context,resources.getString(R.string.nodatos),Toast.LENGTH_SHORT).show()

            }
        }





        builder.setView(view)

        builder.setPositiveButton(android.R.string.yes) { _, _ ->

            if (listener != null) {

                var eleccion = ""
                when (grupo.checkedRadioButtonId) {
                    R.id.radioAnio -> {
                        eleccion = "anio"
                    }
                    R.id.radioTalla -> {
                        eleccion = "talla"
                    }
                    R.id.radioMarca -> {
                        eleccion = "marca"
                    }

                    R.id.radioNada -> {
                        eleccion = "nada"
                    }
                }

                val value = valor.text.toString()

                if ((TextUtils.isEmpty(value) && (grupo.checkedRadioButtonId!=R.id.radioNada))) {

                    valor.error = resources.getString(R.string.escriba_valor)

                } else if(eleccion=="nada") {

                    listener2?.refrescar4(1)

                }else {

                    listener!!.mostrarFiltroUsuario(value, eleccion)

                }

            }

        }

        builder.setNegativeButton(android.R.string.no) { _, _ ->

            Toast.makeText(activity, resources.getString(R.string.cancelado), Toast.LENGTH_LONG).show()

        }

        return builder.create()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is MostrarFiltroUsuario) {

            listener = context

        }


        if (context is Refrescar4) {

            listener2 = context

        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
        listener2 = null
    }


}
