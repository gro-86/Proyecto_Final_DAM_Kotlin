package com.example.myapplication.dialog

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import android.widget.Toast.LENGTH_SHORT
import androidx.fragment.app.DialogFragment
import com.example.myapplication.R
import com.example.myapplication.entities.Producto
import com.example.myapplication.interfaces.Refrescar
import com.example.myapplication.interfaces.Refrescar2
import com.example.myapplication.utils.HelperTrabajador
import com.example.myapplication.utils.Util.Companion.CLAVE_PRODUCTO

class DialogoBorrar : DialogFragment() {

    private lateinit var helper: HelperTrabajador
    private lateinit var producto: Producto
    private var listener: Refrescar?=null
    private var listener2: Refrescar2?=null

    @SuppressLint("InflateParams")
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val inflater = requireActivity().layoutInflater
        val builder= AlertDialog.Builder(activity)
        val view: View = inflater.inflate(R.layout.dialogo_borrar, null)
        builder.setView(view)

        helper = HelperTrabajador()

        if (arguments != null) {

            producto = requireArguments().getSerializable(CLAVE_PRODUCTO) as Producto

        }

        builder.setPositiveButton(android.R.string.yes) { _, _ ->

            val id = producto.idProducto

            var boo = helper.quitarForeign()

            if (!boo) {

                boo = helper.borrarProducto(id)

                if (!boo) {

                    helper.agregarForeign()
                    Toast.makeText(context, resources.getString(R.string.producto_borrado), LENGTH_SHORT).show()

                        listener!!.refrescar()

                } else {

                    Toast.makeText(context, resources.getString(R.string.producto_no_borrado), LENGTH_SHORT).show()

                }

            } else {

                Toast.makeText(
                    context,
                     resources.getString(R.string.desvincular),
                    LENGTH_SHORT
                ).show()

            }

        }

        builder.setNegativeButton(android.R.string.no) { _, _ ->

            Toast.makeText(activity, resources.getString(R.string.cancelado), Toast.LENGTH_LONG).show()

        }

        return builder.create()

    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if(context is Refrescar){
            listener = context
        }


    }

    override fun onDetach() {
        super.onDetach()
        listener=null
    }


}