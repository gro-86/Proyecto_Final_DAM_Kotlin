package com.example.myapplication.dialog

import android.annotation.SuppressLint
import android.app.Activity.RESULT_OK
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.widget.*
import android.widget.Toast.LENGTH_LONG
import android.widget.Toast.LENGTH_SHORT
import androidx.core.content.ContextCompat.checkSelfPermission
import androidx.fragment.app.DialogFragment
import com.example.myapplication.R
import com.example.myapplication.entities.Producto
import com.example.myapplication.interfaces.PasarInformacionFiltro
import com.example.myapplication.interfaces.Refrescar3
import com.example.myapplication.utils.HelperTrabajador
import com.example.myapplication.utils.Util.Companion.IMAGEN_ELEGIDA
import com.example.myapplication.utils.Util.Companion.PERMISO_CODIGO
import com.example.myapplication.utils.Util.Companion.formatoAnio

class DialogoInsertarTrabajador : DialogFragment() {

    private lateinit var helper: HelperTrabajador
    private lateinit var contexto: Context
    private lateinit var imagen: ImageView
    private lateinit var bitmap: Bitmap
    private var listener: PasarInformacionFiltro? = null
    private var listener2: Refrescar3? = null


    @SuppressLint("InflateParams")
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val inflater = requireActivity().layoutInflater
        val builder = AlertDialog.Builder(activity)
        val vista = inflater.inflate(R.layout.dialogo_insertar_trabajador, null)
        builder.setView(vista)

        val talla = vista.findViewById<Spinner>(R.id.spinnerTalla)
        val proveedor = vista.findViewById<Spinner>(R.id.spinnerProveedor)
        val idProducto = vista.findViewById<EditText>(R.id.editIdProducto)
        val marca = vista.findViewById<EditText>(R.id.editMarca)
        val modelo = vista.findViewById<EditText>(R.id.editModelo)
        val anio = vista.findViewById<EditText>(R.id.editAnio)
        val precio = vista.findViewById<EditText>(R.id.editPrecio)
        val cantidad = vista.findViewById<EditText>(R.id.editCantidad)
        val nombreImagen = vista.findViewById<EditText>(R.id.editNombreArchivo)
        contexto = vista.context
        imagen = vista.findViewById(R.id.image_crear_trabajador)
        helper = HelperTrabajador()


        val proveedores = helper.mostrarProveedores()
        val tallas = arrayOf("S", "M", "L", "XL")

        val adapter1 = proveedores?.let {
            ArrayAdapter(
                vista.context, R.layout.support_simple_spinner_dropdown_item,
                it
            )
        }
        val adapter2 =
            ArrayAdapter(vista.context, R.layout.support_simple_spinner_dropdown_item, tallas)

        if (proveedores != null) {
            proveedor.adapter = adapter1
        }

        talla.adapter = adapter2
        imagen.setOnClickListener {
            revisarPermisos()
        }

        builder.setPositiveButton(android.R.string.yes) { _, _ ->

            val tal = talla.selectedItem.toString()

            if (TextUtils.isEmpty(marca.text)) {
                marca.error = resources.getString(R.string.falta_marca)
                marca.requestFocus()
            }
            if (TextUtils.isEmpty(anio.text)) {
                anio.error = resources.getString(R.string.falta_anio)
                anio.requestFocus()
            }
            if (TextUtils.isEmpty(modelo.text)) {
                modelo.error = resources.getString(R.string.falta_modelo)
                modelo.requestFocus()
            }
            if (TextUtils.isEmpty(idProducto.text)) {
                idProducto.error = resources.getString(R.string.falta_id_producto)
                idProducto.requestFocus()
            }
            if (TextUtils.isEmpty(cantidad.text)) {
                cantidad.error = resources.getString(R.string.falta_cantidad)
                cantidad.requestFocus()
            }

            if (TextUtils.isEmpty(precio.text)) {
                precio.error = resources.getString(R.string.falta_precio)
                precio.requestFocus()
            }

            if (TextUtils.isEmpty(nombreImagen.text)) {
                nombreImagen.error = resources.getString(R.string.falta_ruta)
                nombreImagen.requestFocus()
            }

            if (imagen.drawable == null) {
                Toast.makeText(context, resources.getString(R.string.elija_imagen), LENGTH_SHORT)
                    .show()
            }

            if (marca.text.toString().isNotEmpty() && modelo.text.toString().isNotEmpty() &&
                anio.text.toString().isNotEmpty() && idProducto.text.toString().isNotEmpty() &&
                cantidad.text.toString().isNotEmpty() && precio.text.isNotEmpty() &&
                nombreImagen.text.toString().isNotEmpty() && imagen.drawable != null
            ) {

                helper = HelperTrabajador()

                if (helper.buscarIdProveedor(proveedor.selectedItem.toString()) != -1) {

                    val idProv = helper.buscarIdProveedor(proveedor.selectedItem.toString())

                    if (!formatoAnio(anio.text.toString().toInt())) {

                        val producto = Producto(
                            idProducto.text.toString(),
                            marca.text.toString(),
                            modelo.text.toString(),
                            precio.text.toString().toDouble(),
                            anio.text.toString().toInt(),
                            nombreImagen.text.toString(),
                            idProv!!, tal,
                            cantidad.text.toString().toInt()
                        )

                        val boo = helper.crearProducto(producto, bitmap)

                        if (!boo) {

                            Toast.makeText(
                                context,
                                resources.getString(R.string.producto_aniadido),
                                LENGTH_SHORT
                            ).show()


                        } else {

                            Toast.makeText(
                                context,
                                resources.getString(R.string.producto_no_aniadido),
                                LENGTH_SHORT
                            ).show()

                        }

                    }else {

                        Toast.makeText(
                            context,
                            resources.getString(R.string.formato_anio),
                            LENGTH_SHORT
                        ).show()

                    }
                }

            }

        }

        builder.setNegativeButton(android.R.string.no) { _, _ ->
            Toast.makeText(activity, resources.getString(R.string.cancelado), LENGTH_LONG).show()
        }

        return builder.create()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        if (resultCode == RESULT_OK && requestCode == IMAGEN_ELEGIDA) {
            bitmap = data?.extras?.get("data") as Bitmap
            imagen.setImageBitmap(bitmap)
        }
    }


    /**SELECCIONAR IMAGEN DE GALERIA*/
    private fun encenderCamara() {

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, IMAGEN_ELEGIDA)

    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {

        when (requestCode) {

            PERMISO_CODIGO -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PERMISSION_GRANTED) {
                    encenderCamara()
                } else {
                    Toast.makeText(
                        context,
                        resources.getString(R.string.permiso_denegado),
                        LENGTH_SHORT
                    ).show()
                }
            }
        }
    }


    private fun revisarPermisos() {
        if (checkSelfPermission(
                requireContext(),
                android.Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_DENIED ||
            checkSelfPermission(
                requireContext(),
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_DENIED
        ) {

            val permisos = arrayOf(
                android.Manifest.permission.CAMERA,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            requestPermissions(permisos, PERMISO_CODIGO)

        } else {
            encenderCamara()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is PasarInformacionFiltro) {
            listener = context
        }

        if (context is Refrescar3) {
            listener2 = context
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        listener = null
        listener2 = null
    }

}