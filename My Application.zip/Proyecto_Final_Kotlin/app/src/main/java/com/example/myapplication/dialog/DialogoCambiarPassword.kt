package com.example.myapplication.dialog

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.example.myapplication.R
import com.example.myapplication.utils.HelperUsuario

class DialogoCambiarPassword : DialogFragment(), TextWatcher {


    private lateinit var user: TextView
    private lateinit var pass1: EditText
    private lateinit var pass2: EditText
    private var boo: Boolean = false
    private lateinit var usuario: String
    private lateinit var password: String

    @SuppressLint("InflateParams")
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val inflater = requireActivity().layoutInflater
        val builder: AlertDialog.Builder = AlertDialog.Builder(activity)
        val view: View = inflater.inflate(R.layout.dialogo_cambiar_password, null)
        builder.setView(view)

        user = view.findViewById(R.id.textPassword)
        pass1 = view.findViewById(R.id.editPass1)
        pass2 = view.findViewById(R.id.editPass2)

        usuario = requireArguments().getString("user")!!
        password = requireArguments().getString("pass")!!

        user.text = usuario

        pass1.addTextChangedListener(this)
        pass2.addTextChangedListener(this)


        builder.setPositiveButton(android.R.string.yes) { _, _ ->

            if (boo) {

                val helper = HelperUsuario()
                val md = helper.crearMD5(pass1.text.toString())
                val bool = helper.cambiarPassword(md, usuario)

                if (!bool) {

                    Toast.makeText(activity, resources.getString(R.string.password_cambiado), Toast.LENGTH_SHORT).show()

                } else {

                    Toast.makeText(activity, resources.getString(R.string.error), Toast.LENGTH_SHORT).show()

                }
            }

        }

        builder.setNegativeButton(android.R.string.no) { _, _ ->

            Toast.makeText(activity, resources.getString(R.string.cancelado), Toast.LENGTH_LONG).show()

        }

        return builder.create()

    }

    override fun afterTextChanged(s: Editable?) {

        boo = pass1.text.toString().isNotEmpty() && pass2.text.toString().isNotEmpty() &&
                pass1.text.toString() == pass2.text.toString()

    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

        boo = pass1.text.toString().isNotEmpty() && pass2.text.toString().isNotEmpty() &&
                pass1.text.toString() == pass2.text.toString()

    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

    }

}