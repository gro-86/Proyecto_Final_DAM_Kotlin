package com.example.myapplication.fragments.trabajador

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.fragment.app.Fragment
import com.example.myapplication.R
import com.example.myapplication.interfaces.ComunicarFiltro
import com.example.myapplication.interfaces.PasarInformacionFiltro
import com.example.myapplication.interfaces.Refrescar3
import com.example.myapplication.utils.HelperTrabajador


class FragmentFiltroTrabajador : Fragment() {

    private var listener: PasarInformacionFiltro? = null
    private var listener2: ComunicarFiltro? = null

    @SuppressLint("ResourceAsColor")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val vista = inflater.inflate(R.layout.fragment_eleccion, container, false)
        val spinner = vista.findViewById<Spinner>(R.id.spinner_usuarios_trabajador)
        val boton = vista.findViewById<Button>(R.id.btn_filtro_trabajador)
        val helper = HelperTrabajador()
        val usuarios = helper.mostrarUsuarios()
        val adaptador = usuarios?.let {
            ArrayAdapter(
                vista.context, R.layout.item_spinner_dropdown, it
            )
        }

        if (usuarios != null) {
            spinner.adapter = adaptador
        }

        boton.setOnClickListener {


            if (Configuration.ORIENTATION_LANDSCAPE == resources.configuration.orientation) {

                listener2?.comunicarFiltro(spinner.selectedItem.toString())


            } else if (Configuration.ORIENTATION_PORTRAIT == resources.configuration.orientation) {

                listener?.pasarInformacionFiltro(spinner.selectedItem.toString(),true)

            }


        }

        return vista
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is PasarInformacionFiltro) {

            listener = context

        }

        if (context is ComunicarFiltro) {

            listener2 = context

        }


    }

    override fun onDestroy() {
        super.onDestroy()
        listener = null
        listener2 = null

    }


}