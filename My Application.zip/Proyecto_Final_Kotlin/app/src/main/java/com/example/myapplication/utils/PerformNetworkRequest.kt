package com.example.myapplication.utils

import android.os.AsyncTask

class PerformNetworkRequest(private var urlCreateUser: String, private var parametro: HashMap<String, String>?, private var codePostRequest: Int
) : AsyncTask<Void, Void, String>() {


    override fun onPreExecute() {
        super.onPreExecute()
    }

    override fun onPostExecute(result: String?) {
        super.onPostExecute(result)
    }

     override fun onProgressUpdate(vararg values: Void?) {
        super.onProgressUpdate(*values)
    }


    override fun doInBackground(vararg params: Void?): String? {
        val requestHandler = RequestHandler()

        if (codePostRequest == Util.CODE_POST_REQUEST)
            return requestHandler.sendPostRequest(urlCreateUser,parametro!!)

        if (codePostRequest == Util.CODE_GET_REQUEST)
            return requestHandler.sendGetRequest(urlCreateUser)

        return null
    }


}