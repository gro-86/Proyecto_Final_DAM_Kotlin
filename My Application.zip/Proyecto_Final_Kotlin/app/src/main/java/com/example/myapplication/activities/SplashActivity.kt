package com.example.myapplication.activities

import android.animation.ObjectAnimator
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.ProgressBar
import com.example.myapplication.R


class SplashActivity : AppCompatActivity() {

    companion object {
        var splashProgress: ProgressBar?=null
        const val SPLASH_TIME = 3000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        splashProgress = findViewById(
            R.id.splashProgress
        )
        mostrarProgreso()

         Handler().postDelayed({

                val mySuperIntent =  Intent(applicationContext, MainActivity::class.java)
                startActivity(mySuperIntent)

                finish()

        },
             SPLASH_TIME
         )
    }

    /**MOSTRAR PROGRESO CARGA SPLASH*/
    private fun mostrarProgreso() {
        ObjectAnimator.ofInt(splashProgress, "progress", 100)
            .setDuration(3000)
            .start()
    }
}
