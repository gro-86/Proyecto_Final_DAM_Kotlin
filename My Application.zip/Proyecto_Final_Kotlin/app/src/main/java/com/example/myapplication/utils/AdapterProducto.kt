package com.example.myapplication.utils

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import com.example.myapplication.entities.Producto
import com.example.myapplication.R
import com.squareup.picasso.Picasso

class AdapterProducto (private var contexto: Context,private var recurso:Int,private var listaProductos: ArrayList<Producto>) :
    ArrayAdapter<Producto>(contexto,recurso,listaProductos) {

    @SuppressLint("ViewHolder", "SetTextI18n")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val inflater = LayoutInflater.from(contexto)
        val view = inflater.inflate(recurso,null)

        val idProducto = view.findViewById(R.id.text_id_producto_usuario) as TextView
        val marca = view.findViewById(R.id.text_marca_usuario) as TextView
        val descripcion = view.findViewById(R.id.text_descripcion_usuario) as TextView
        val talla = view.findViewById(R.id.text_talla_usuario) as TextView
        val precio = view.findViewById(R.id.text_precio_usuario) as TextView
        val imagen = view.findViewById(R.id.imagen_recycler_usuario) as ImageView
        val cantidad = view.findViewById(R.id.text_cantidad_usuario) as TextView
        val idProveedor = view.findViewById(R.id.text_id_proveedor_usuario) as TextView
        val anio = view.findViewById(R.id.text_anio_usuario) as TextView

        val type: Typeface? = ResourcesCompat.getFont(contexto, R.font.cinzel_bold)
        idProducto.typeface = type
        marca.typeface = type
        descripcion.typeface = type
        talla.typeface = type
        precio.typeface = type
        cantidad.typeface = type
        idProveedor.typeface = type
        anio.typeface = type

        if(view.resources.configuration.screenLayout and
                Configuration.SCREENLAYOUT_SIZE_MASK ==
                Configuration.SCREENLAYOUT_SIZE_XLARGE){

            idProducto.textSize= 30F
            marca.textSize= 30F
            descripcion.textSize= 30F
            talla.textSize= 30F
            precio.textSize= 30F
            cantidad.textSize= 30F
            idProveedor.textSize= 30F
            anio.textSize= 30F
            imagen.maxWidth=190
            imagen.maxHeight=190

        }

        val producto: Producto = listaProductos[position]
        idProducto.text = producto.idProducto
        marca.text = producto.marca
        descripcion.text = producto.modelo
        talla.text = contexto.resources.getString(R.string.talla)+" ${producto.talla}"
        precio.text = "${producto.precio}€"
        cantidad.text = producto.cantidad.toString()
        idProveedor.text = producto.idProveedor.toString()
        anio.text = producto.anioCreacion.toString()

        Picasso.get()
            .load("${Util.URL_IMAGES}${listaProductos[position].foto}")
            .into(imagen)

        return view

    }

}