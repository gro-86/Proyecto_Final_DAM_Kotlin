package com.example.myapplication.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.myapplication.R
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val delicias = LatLng(41.6512709,-0.9157372)
        mMap.addMarker( MarkerOptions().position(delicias).title("Delicias"))
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(delicias, 16F))
        val arrabal = LatLng(41.660443,-0.8777147)
        mMap.addMarker( MarkerOptions().position(arrabal).title("Arrabal"))
        val valdefierro = LatLng(41.6379299,-0.9307246)
        mMap.addMarker( MarkerOptions().position(valdefierro).title("Valdefierro"))
        val montecanal = LatLng(41.6277243,-0.9263803)
        mMap.addMarker( MarkerOptions().position(montecanal).title("Montecanal"))
        val montanana = LatLng(41.686332,-0.8287331)
        mMap.addMarker( MarkerOptions().position(montanana).title("Montañana"))
        val centro = LatLng(41.6504069,-0.8847566)
        mMap.addMarker( MarkerOptions().position(centro).title("Centro"))

        mMap.setOnMapClickListener {
            mMap.addMarker(MarkerOptions().position(it)
                .icon(BitmapDescriptorFactory.fromResource(android.R.drawable.ic_menu_compass)))

            val options =  MarkerOptions()
            options.position(it)
            options.title("${it.latitude} : ${it.longitude}")
            mMap.addMarker(options)
            Toast.makeText(applicationContext, resources.getString(R.string.latitud) + it.latitude + " "+resources.getString(R.string.longitud)+":" + it.longitude, Toast.LENGTH_LONG).show()

        }

        mMap.setOnMapLongClickListener {
            mMap.addMarker( MarkerOptions().position(it)
                .icon(BitmapDescriptorFactory.fromResource(android.R.drawable.ic_menu_compass)))
            Toast.makeText(applicationContext, resources.getString(R.string.latitud)+":" + it.latitude + " "+resources.getString(R.string.longitud)+":" + it.longitude, Toast.LENGTH_LONG).show()

        }

    }
}
